# piedra papel o tijera
puntaje = 0
while True:
    try:
        from Piedra_papel_tijera.configuracion import configuraciones  as  cf
        from Piedra_papel_tijera.UI import interfaz_terminal as i
        from Piedra_papel_tijera.puntajes import Puntaje as p
        from Piedra_papel_tijera.info import ver_info as info
        from Piedra_papel_tijera.Juego import Nivel_
        break
    except ModuleNotFoundError:
        print("No se encontro un archivo: ")

class piedra_papel_o_tijera:
    def __init__(self):
        self.juego = Nivel_()
    def inicio(self):
        while True:
            cf.limpiar_pantalla()
            i.menu_principal()
            opcion = cf.entrada_us()
            opciones = {
                1:self.juego.juego,
                2:p.ver_puntaje,
                3:info.INFO
            }
            if opcion in opciones:
                cf.limpiar_pantalla()
                opciones[opcion]()
            elif opcion == 4:
                cf.limpiar_pantalla()
                break
            else:
                cf.limpiar_pantalla()
            