#info

while True:
    try:
        from Piedra_papel_tijera.configuracion import configuraciones as cf
        break

    except ModuleNotFoundError:
        print("No se encontro un archivo")


class ver_info:
    @staticmethod
    def INFO():
        cf.limpiar_pantalla()
        with open("Piedra_papel_tijera/info.txt", "r") as f:
            for linea in f:
                print(linea)
        cf.pausa()