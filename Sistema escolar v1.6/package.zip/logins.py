# Logins Sistema escolar
def error_():
    print('[Errror critico] No se encuentran los demas archivos:')

while True:
    try:
        from configuracion import Configuracion as cf
        from auth.Autenthication import contraseña_directivo_1, contraseña_directivo_2, contraseña_directivo_3
        break

    except ModuleNotFoundError:
        error_()

def login_docente():
    while True:
        try:
            contraseña = contraseña_directivo_3()
            cf.es()
            contraseña_docente = int(input('!Hola profe¡, porfavor escribe tu clave:'))
            while contraseña_docente != contraseña:
                cf.es()
                cf.limpiar_pantalla()
                contraseña_docente = int(input('[ERROR]!Clave incorrecta¡:'))
                cf.es()
            break

        except ValueError:
            cf.error()

def login_coordinador():
    while True:
        try:
            contraseña = contraseña_directivo_2()
            cf.es()
            contraseña_coordinador = int(input('¡!Hola cordinador por favor dijita tu clave!¡:'))
            while contraseña_coordinador != contraseña:
                cf.es()
                cf.limpiar_pantalla()
                contraseña_coordinador = int(input('?Acaso no eres el cordinador¿'))
                cf.es()
            break

        except ValueError:
            cf.error()

def login_rector():
    while True:
        try:
            contraseña = contraseña_directivo_1()
            cf.es()
            contraseña_rector = int(input('¡!Hola rector!¡, Por favor dijita la clave:'))
            while contraseña_rector != contraseña:
                cf.es()
                cf.limpiar_pantalla()
                contraseña_rector = int(input('[ERROR]!Clave incorrecta¡:'))
                cf.es()
            break

        except ValueError:
            cf.error()

def login_menu_principal():
    while True:
        try:
            colegio = str(input('Por favor escribe colegio python para continuar:')).lower()
            break

        except EOFError:
            cf.Eof()             

    while colegio != 'colegio python':
        cf.es()
        cf.limpiar_pantalla()
        colegio = str(input('[ERROR] colegio incorrecto:')).lower()
        cf.es()
