#Submenus compromisos

while True:
    try:
        from UI import Submenus as itz
        from configuracion import Configuracion as cf
        from utilidades import compromisos_1,compromisos_2,compromisos_3,compromisos_4,compromisos_5
        break

    except ModuleNotFoundError:
        print("NO SE ENCONTRO UN ARCHIVO:::")

class compromisos_:
    def compromisos(self):
        while True:
            cf.limpiar_pantalla()
            itz.submenu_compromisos_()
            Compromiso_s = cf.entrada()
            compromisos_opcion = {
                1: compromisos_1,
                2: compromisos_2,
                3: compromisos_3,
                4: compromisos_4,
                5: compromisos_5
            }        
            
            if Compromiso_s in compromisos_opcion:
                cf.limpiar_pantalla()
                compromisos_opcion[Compromiso_s]()

            elif Compromiso_s == 6:
                cf.volver()
                cf.limpiar_pantalla()
                break