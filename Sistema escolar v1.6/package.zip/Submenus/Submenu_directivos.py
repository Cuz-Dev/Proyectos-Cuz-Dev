#Submenu directivos
while True:
    try:
        from configuracion import Configuracion as cf
        from UI import Submenus as itz
        from utilidades import directivos_lista
        break
    except ModuleNotFoundError:
        print("No se encontro un archivo")

class SubmenuDirectivos:
    def __init__(self):
        self.directivo_1 = directivo1()
        self.directivo_2 = directivo2()
        self.directivo_3 = directivo3()
        self.dorectivo_4 = directivo4()

    def submenu_directivos(self):
        while True:
            cf.limpiar_pantalla()
            itz.submenu_directivos_()
            directivos = cf.entrada()
            opciones_directivos = {
                1: self.directivo_1.submenu_directivos1,
                2: self.directivo_2.submenu_directivos2,
                3: self.directivo_3.submenu_directivos3,
                4: self.dorectivo_4.submenu_directivos4
            }

            if directivos in opciones_directivos:
                cf.limpiar_pantalla()
                opciones_directivos[directivos]()

            elif directivos == 5:
                cf.volver()
                cf.limpiar_pantalla()
                break

class directivo1:   
    def submenu_directivos1(self):
        while True:          
            cf.limpiar_pantalla()
            itz.submenu_directivos_1()
            Rector = cf.entrada()
            opciones_rector = {
                1: directivos_lista[0],
                2: directivos_lista[1]
            }

            if Rector in opciones_rector:
                cf.limpiar_pantalla()
                opciones_rector[Rector]()

            elif Rector == 3:
                cf.volver()
                cf.limpiar_pantalla()
                break

class directivo2:
    def submenu_directivos2(self):
        while True:
            cf.limpiar_pantalla()
            itz.submenu_directivos_2()
            Coordinador = cf.entrada()
            opciones_coordinador = {
                1: directivos_lista[2],
                2: directivos_lista[3]
            }

            if Coordinador in opciones_coordinador:
                cf.limpiar_pantalla()
                opciones_coordinador[Coordinador]()

            elif Coordinador == 3:
                cf.volver()
                cf.limpiar_pantalla()
                break       

class directivo3:
    def submenu_directivos3(self):
        while True:
            cf.limpiar_pantalla()
            itz.submenu_directivos_3()
            psicologa = cf.entrada()
            opciones_psicologa = {
                1: directivos_lista[4],
                2: directivos_lista[5]
            }

            if psicologa in opciones_psicologa:
                cf.limpiar_pantalla()
                opciones_psicologa[psicologa]()

            elif psicologa == 3:
                cf.volver()
                cf.limpiar_pantalla()
                break       

class directivo4:
    def submenu_directivos4(self):
        while True:
            cf.limpiar_pantalla()
            itz.submenu_directivos_4()
            secretario = cf.entrada()
            opciones_secretario = {
                1: directivos_lista[6],
                2: directivos_lista[7]
            }

            if secretario in opciones_secretario:
                cf.limpiar_pantalla()
                opciones_secretario[secretario]()

            elif secretario == 3:
                cf.volver()
                break