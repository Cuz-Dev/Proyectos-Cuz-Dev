#Submenu eventos

while True:
    try:
        from configuracion import Configuracion as cf
        from UI import Submenus as itz
        from utilidades import eventos_lista
        break

    except ModuleNotFoundError:
        print("No se encontro un archivo")

class SubmenuEventos:
    def __init__(self):
        self.eventos_1 = Eventos1()
        self.eventos_2 = Eventos2()
        self.eventos_3 = Eventos3()
        self.eventos_4 = Eventos4()
        self.eventos_5 = Eventos5()

    def submenu_eventos(self):
        while True:
            cf.limpiar_pantalla()
            itz.submenu_eventos_()
            eventos = cf.entrada()
            opciones_area = {
                1: self.eventos_1.submenu_eventos1,
                2: self.eventos_2.submenu_eventos2,
                3: self.eventos_3.submenu_eventos3,
                4: self.eventos_4.submenu_eventos4,
                5: self.eventos_5.submenu_eventos5
            }
            if eventos in opciones_area:
                cf.limpiar_pantalla()
                opciones_area[eventos]()

            elif eventos == 6:
                cf.volver()
                cf.limpiar_pantalla()
                break

class Eventos1:
    def submenu_eventos1(self):
        while True:
            cf.limpiar_pantalla()
            itz.submenu_eventos_1()
            cultura = cf.entrada()
            opciones_cultura = {
                1: eventos_lista[0],
                2: eventos_lista[1]
            }
                
            if cultura in opciones_cultura:
                cf.limpiar_pantalla()
                opciones_cultura[cultura]()

            elif cultura == 3:
                cf.volver()
                cf.limpiar_pantalla()
                break    
class Eventos2:
    def submenu_eventos2(self):
        while True:
            cf.limpiar_pantalla()
            cf.submenu_eventos_2()
            feria = cf.entrada()        
            opciones_feria = {
                1: eventos_lista[2],
                2: eventos_lista[3]
            }

            if feria in opciones_feria:
                cf.limpiar_pantalla()
                opciones_feria[feria]()

            elif feria == 3:
                cf.volver()
                cf.limpiar_pantalla()
                break    

class Eventos3:
    def submenu_eventos3():
        while True:
            cf.limpiar_pantalla()
            itz.submenu_eventos_3()
            izada = cf.entrada()
            opciones_izada = {
                1: eventos_lista[4],
                2: eventos_lista[5]
            }

            if izada in opciones_izada:
                cf.limpiar_pantalla()
                opciones_izada[izada]()

            elif izada == 3:
                cf.volver()
                cf.limpiar_pantalla()
                break 

class Eventos4:
    def submenu_eventos4(self):
        while True:
            cf.limpiar_pantalla()
            itz.submenu_eventos_4()
            independencia = cf.entrada()
            opciones_independencia = {
                1: eventos_lista[6],
                2: eventos_lista[7]
            }

            if independencia in opciones_independencia:
                cf.limpiar_pantalla()
                opciones_independencia[independencia]()

            elif independencia == 3:
                cf.volver()
                cf.limpiar_pantalla()
                break

class Eventos5:
    def submenu_eventos5(self):
        while True:
            cf.limpiar_pantalla()
            itz.submenu_eventos_5()
            reunion_acu = cf.entrada()
            opciones_reuniones = {
                1: eventos_lista[8],
                2: eventos_lista[9]
            }

            if reunion_acu in opciones_reuniones:
                cf.limpiar_pantalla()
                opciones_reuniones[reunion_acu]()

            elif reunion_acu == 3:
                cf.volver()
                cf.limpiar_pantalla()
                break