#Submenus reuiniones 

while True:
    try:
        from configuracion import Configuracion as cf
        from UI import Submenus as itz
        from utilidades import reuniones_1,reuniones_2,reuniones_3,reuniones_4,reuniones_5
        break

    except ModuleNotFoundError:
        print("No se encontro un archivo")

class reuniones_:
    def reuniones(self):
        while True:
            cf.limpiar_pantalla()
            itz.submenu_reuniones()
            Reuniones = cf.entrada()
            reuniones_opcion = {

                1: reuniones_1,
                2: reuniones_2,
                3: reuniones_3,
                4: reuniones_4,
                5: reuniones_5

            }

            if Reuniones in reuniones_opcion:
                cf.limpiar_pantalla()
                reuniones_opcion[Reuniones]()

            elif Reuniones == 6:
                cf.volver()
                cf.limpiar_pantalla()
                break