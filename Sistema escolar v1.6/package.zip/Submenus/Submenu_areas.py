#Submenu areas

while True:
    try:
        from configuracion import Configuracion as cf
        from UI import Submenus as itz
        from utilidades import temas_area_lista
        break

    except ModuleNotFoundError:
        print("no se encontro un archivo")

class SubmenuAreas:
    def submenu_areas(self):
        cf.limpiar_pantalla()
        while True:      
            itz.submenu_areas_()
            opcion_areas = cf.entrada()
            opciones_area = {

                1: temas_area_lista[0],
                2: temas_area_lista[1],
                3: temas_area_lista[2],
                4: temas_area_lista[3],
                5: temas_area_lista[4],
                6: temas_area_lista[5],
                7: temas_area_lista[6],
                8: temas_area_lista[7],
                9: temas_area_lista[8],
                10: temas_area_lista[9],
                11: temas_area_lista[10],
                12: temas_area_lista[11]

            }

            if opcion_areas in opciones_area:
                cf.limpiar_pantalla()
                opciones_area[opcion_areas]()
    
            elif opcion_areas == 13:
                cf.volver()
                cf.limpiar_pantalla()
                break