#Submenu docentes area

while True:
    try:
        from configuracion import Configuracion as cf
        from UI import Submenus as itz
        from utilidades import docentes_area
        break
    except ModuleNotFoundError:
        print("No SE ENCONTRO UN ARCHIVO")

class Docente_por_area:
    def submenu_docentes_area(self):
        while True:
            cf.limpiar_pantalla()
            itz.submenu_docentes_area_()      
            docente_area = cf.entrada()
            opcion_docente_area = {

                1: docentes_area[0],
                2: docentes_area[1],
                3: docentes_area[2],
                4: docentes_area[3],
                5: docentes_area[4],
                6: docentes_area[5],
                7: docentes_area[6],
                8: docentes_area[7],
                9: docentes_area[8],
                10: docentes_area[9],
                11: docentes_area[10],
                12: docentes_area[11]

            }

            if docente_area in opcion_docente_area:
                cf.limpiar_pantalla()
                opcion_docente_area[docente_area]()

            elif docente_area == 13:
                cf.volver()
                cf.limpiar_pantalla()
                break 