#nivel 2
while True:
    try:
        import random
        from Number_Hunter.configuracion import configuraciones as cf
        from Number_Hunter.niveles.nivel_3 import Nivel_3
        from Number_Hunter.UI import interfaz_de_terminal as i
        break

    except ModuleNotFoundError:
        print("No se encontro el archivo")

class Nivel_2:
    @staticmethod
    def nivel():
        puntaje = 10
        while True:
            cf.limpiar_pantalla()
            i.nivel(puntaje,nivel=2,numero=20)
            maquina = random.randint(1,20)
            numero_usuario = cf.pedir_numero()
            cf.limpiar_pantalla()
            if numero_usuario == maquina:
                Nivel_3.nivel()
            elif numero_usuario == 0:
                cf.guardar_puntaje(puntaje)
            else:
                cf.limpiar_pantalla()
                cf.game_over(maquina)
                break
            