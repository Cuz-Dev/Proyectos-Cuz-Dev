#number hunter v3
#desarrollador cuz-dev

while True:
    try:
        from Number_Hunter.configuracion import configuraciones as cf
        from Number_Hunter.UI import interfaz_de_terminal as inf
        from Number_Hunter.niveles import Nivel_1
        from Number_Hunter.info import leer
        from Number_Hunter.ver_puntajes import puntaje
        break
    except ModuleNotFoundError:
        print("No se encontro un archivo")

class  Number_hunter:
    def Menu_principal(self):
        while True:
            cf.limpiar_pantalla()
            inf.Menu_principal()
            opcion = cf.entrada_us()
            opciones = {
                1:Nivel_1.Nivel,
                2:leer.leer_info,
                3:puntaje.ver_Puntaje
            }
            if opcion in opciones:
                cf.limpiar_pantalla()
                opciones[opcion]()

            elif opcion == 4:
                cf.limpiar_pantalla()
                break
            
            else:
                cf.limpiar_pantalla()

