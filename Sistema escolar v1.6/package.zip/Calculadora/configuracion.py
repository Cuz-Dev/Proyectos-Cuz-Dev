import os
def p(mensaje):
    print(mensaje)

def es():
    p('   ')

def error_numero():
    print("[ERROR] Debes escribir un numero no una letra: ")

def limpiar_pantalla():
    if os.name == "nt":
        os.system("cls")

    else:
        os.system("clear")

def pedir_numero_1():
    while True:
        try:
            numero = int(input("Escribe el primer numero: "))
            break

        except ValueError:
            error_numero()
    return numero

def pedir_numero_2():
    while True:
        try:
            numero = int(input("Escribe el segundo numero: "))
            break
        except ModuleNotFoundError:
            error_numero()
    return numero

def entrada_us():
    while True:
        try:
            entrada = int(input("Digita numero: "))
            break

        except ValueError:
            error_numero()
    return entrada

def pause():
    input("Click enter para continuar")

def resultado_Suma():
    print("Resultado Suma")
    es()

def resultado_Resta():
    print("Resultado Resta")
    es()

def resultado_Multiplicacion():
    print("Resultado Multiplicacion")
    es()

def resultado_Division():
    print("Resultado Division")
    es()