#Calculadora basica
#🚀desarrollador Cuz-Dev🚀

def error_():
    print("[ERROR]NO se encuentra un archivo necesario")

while True:
    try:
        from Calculadora.configuracion import es, limpiar_pantalla, entrada_us
        from Calculadora.UI import menu_principal
        from Calculadora.operaciones import SubMenu_suma, SubMenu_resta, SubMenu_division, SubMenu_Multiplicacion
        break

    except ModuleNotFoundError:
        error_()
        
class calculadora:
    def __init__(self):
        self.suma = SubMenu_suma()
        self.resta = SubMenu_resta()
        self.multiplicacion = SubMenu_Multiplicacion()
        self.division = SubMenu_division()

    def menu_principal(self):
        while True:
            limpiar_pantalla()
            menu_principal()
            entrada = entrada_us()
            opciones = {
                1:self.suma.sub_menu_suma,
                2:self.resta.sub_menu_resta,
                3:self.multiplicacion.sub_menu_multiplicaion,
                4:self.division.sub_menu_division
            }
            if entrada in opciones:
                opciones[entrada]()

            elif entrada == 5:
                limpiar_pantalla()
                break

            else:
                break
