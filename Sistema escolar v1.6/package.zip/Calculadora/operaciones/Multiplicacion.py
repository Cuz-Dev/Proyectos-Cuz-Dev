
# Multiplicacion

while True:
    try:
        from Calculadora.configuracion import es, limpiar_pantalla,pedir_numero_1,pedir_numero_2,resultado_Multiplicacion
        from Calculadora.configuracion import pause
        from Calculadora.UI import submenu_multiplicacion
        break

    except ModuleNotFoundError:
        print("[ERROR] No se encuentra un archivo necesario para la ajecucion:")

class Multiplicacion:
    def __init__(self):
        self.resultado = 0

    def multiplicacion(self):
        limpiar_pantalla()
        self.numero_1 = pedir_numero_1()
        es()
        self.numero_2 = pedir_numero_2()
        self.resultado_multiplicacion()

    def resultado_multiplicacion(self):
        self.resultado = self.numero_1 * self.numero_2

class SubMenu_Multiplicacion(Multiplicacion):
    def sub_menu_multiplicaion(self):
        while True:
            limpiar_pantalla()
            submenu_multiplicacion()
            self.multiplicacion()
            limpiar_pantalla()
            resultado_Multiplicacion()
            print(self.resultado)
            pause()
            break