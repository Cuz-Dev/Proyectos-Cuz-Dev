
#Division

def error_numero():
    print("[ERROR] Debes escribir un numero no una letra: ")

while True:
    try:
        from Calculadora.configuracion import es,entrada_us,limpiar_pantalla,pedir_numero_1,pedir_numero_2
        from Calculadora.configuracion import resultado_Division,pause
        from Calculadora.UI import submenu_division
        break

    except ModuleNotFoundError:
        print("[ERROR] No se encunetra un archivo necesario para la ejecucion")

class Division:
    def __init__(self):
        self.resultado = 0

    def division(self):
        limpiar_pantalla()
        self.numero_1 = pedir_numero_1()
        es()
        self.numero_2 = pedir_numero_2()
        self.resultado_division()

    def resultado_division(self):
        self.resultado = self.numero_1 / self.numero_2

class SubMenu_division(Division):
    def sub_menu_division(self):
        while True:
            limpiar_pantalla()
            submenu_division()
            self.division()
            limpiar_pantalla()
            resultado_Division()
            print(self.resultado)
            pause()
            break
