#Suma

def error_():
    print('[ERROR] No se encuntra un archivo necesario para la ejecucion: ')

while True:
    try:
        from Calculadora.configuracion import limpiar_pantalla,es,entrada_us,pedir_numero_1,pedir_numero_2,resultado_Suma
        from Calculadora.configuracion import pause
        from Calculadora.UI import submenu_suma
        break

    except ModuleNotFoundError:
        error_()

class Suma:
    def __init__(self):
        self.resultado = 0

    def suma(self):
        limpiar_pantalla()
        self.numero_1 = pedir_numero_1()
        es()
        self.numero_2 = pedir_numero_2()
        self.resultado_suma()

    def resultado_suma(self):
        self.resultado = self.numero_1 + self.numero_2

class SubMenu_suma(Suma):
    def sub_menu_suma(self):
        while True:
            limpiar_pantalla()
            submenu_suma()
            es()
            self.suma()
            limpiar_pantalla()
            resultado_Suma()
            print(self.resultado)
            pause()
            break