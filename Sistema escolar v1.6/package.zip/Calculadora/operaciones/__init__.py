#paquete
while True:
    try:
        from .Suma import SubMenu_suma
        from .Resta import SubMenu_resta
        from .Multiplicacion import SubMenu_Multiplicacion
        from .Division import SubMenu_division
        break

    except ModuleNotFoundError:
        break