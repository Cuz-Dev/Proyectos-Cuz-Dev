
#Resta

def error_numero():
    print("[ERROR] Debes escribir un numero no una letra: ")

while True:
    try:
        from Calculadora.configuracion import pause,limpiar_pantalla,es,pedir_numero_1,pedir_numero_2
        from Calculadora.configuracion import resultado_Resta
        from Calculadora.UI import submenu_resta
        break

    except ModuleNotFoundError:
        print("[ERROR] No se encuentra un archivo necesario para la ejecucion: ")

class Resta:
    def __init__(self):
        self.resultado = 0

    def resta(self):
        limpiar_pantalla()
        self.numero_1 = pedir_numero_1()
        es()
        self.numero_2 = pedir_numero_2()
        self.resultado_resta()

    def resultado_resta(self):
        self.resultado = self.numero_1 - self.numero_2

class SubMenu_resta(Resta):
    def sub_menu_resta(self):
        while True:
            limpiar_pantalla()
            submenu_resta()
            self.resta()
            limpiar_pantalla()
            resultado_Resta()
            print(self.resultado)
            pause()
            break
            
            
