# Ui
def error_():
    print('[ERROR] No se encuntra un archivo neseraio para la ejecucion: ')

while True:
    try:
        from Calculadora.configuracion import p,es
        break

    except ModuleNotFoundError:
        error_()

def menu_principal():
    p(' ╔══════════════════════════════════════════╗')
    p('                  Calculadora                   ')
    p('   ═══════            v.3')
    p('╚════════════════════════════════════════════════╝')
    p('1* Suma ')
    p('2* Resta')
    p('3* Multipicacion')
    p('4* Division')
    p("5* <<<< Volver")

def submenu_suma():
    p('➤ Suma')
    es()

def submenu_resta():
    p('➤ Resta')
    es()

def submenu_multiplicacion():
    p('➤ Multiplicacion')
    es()

def submenu_division():
    p('➤ Division')
    es()