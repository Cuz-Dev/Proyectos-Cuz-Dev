# Interfaz de terminal de Sistema
def error_():
    print('[Errror critico] No se encuentran los demas archivos:')

while True:
    try:
        from configuracion import Configuracion as cf
        break

    except ModuleNotFoundError:
        error_()

class Menus:
    @staticmethod
    def menu_docente():
        cf.es()
        cf.p('     ║╔══════════════════════════════════════════╗')
        cf.p('  ║ ════                 Menu Docente                ║')
        cf.p('╚═══════════════════════════════════════════════ ╝ ╦═════════╗')
        cf.p('                                                  ║         ')
        cf.p('╔                                                            ╗')
        cf.p(' [1] Ver areas   | [4] Estudiantes       | [7] <<<< salir')
        cf.p(' [2] Eventos     | [5] Contraseña        ')
        cf.p(' [3] Directivos  | [6] Acudientes         ')
        cf.p('╚                                                            ╝')
        cf.es()
    @staticmethod
    def menu_coordinador_():
        cf.p('  ║  ╔══════════════════════════════════════════╗══')
        cf.p(' ║                  Menu Coordinador            ║')
        cf.p('╚═══════════════════════════════════════════════ ╝ ╦═════════════════╗')
        cf.p('                                                  ║                 ══')
        cf.p('╔                                                                  ╗')
        cf.p(' [1] Compromisos        |[5] Contraseña')
        cf.p(' [2] Reuniones          |[6] Acudientes')
        cf.p(' [3] Docentes           |[7] <<<< salir')
        cf.p(' [4] Estudiantes       ')
        cf.p('╚                                                                  ╝')
        cf.es()
        cf.es()
    @staticmethod
    def menu_acudiente_():
        cf.p('  ║  ╔══════════════════════════════════════════╗')
        cf.p(' ║              Menu Acudiente                  ║')
        cf.p('╚════════════════════════════════════════════════╝')
        cf.es()
        cf.p('╔                                                ╗')
        cf.p(' [1] Estudiantes')
        cf.p(' [2] Docentes')
        cf.p(' [3] Directivos')
        cf.p(' [4] Eventos')
        cf.p(' [5] Anotaciones')
        cf.p(' [6] <<<< salir')
        cf.p('╚                                                ╝')
        cf.es()
    @staticmethod
    def menu_es():
        cf.p('║  ╔══════════════════════════════════════════╗')
        cf.p('  ║         Menu estudiante                           ║')
        cf.p('╚════════════════════════════════════════════════╝')
        cf.es()
        cf.p('╔                                                ╗')
        cf.p(' [1] Temas')
        cf.p(' [2] Directivos')
        cf.p(' [3] Grados')
        cf.p(' [4] Anotaciones')
        cf.p(' [5] <<<< Salir')
        cf.p('╚                                                ╝')
        cf.es()
    @staticmethod
    def menu_herramientas_():
        cf.p('║  ╔══════════════════════════════════════════╗')
        cf.p('  ║             Menu herramientas         ║       ')
        cf.p('╚════════════════════════════════════════════════╝')
        cf.es()
        cf.p('╔                                       ╗')
        cf.p(' [1] Calculadora')
        cf.p(' [2] Juegos')
        cf.p(' [3] <<<< Salir')
        cf.p('╚                                        ╝')
        cf.es()
    @staticmethod
    def menu_rector_():
        cf.es()
        cf.p('║  ╔══════════════════════════════════════════╗')
        cf.p('  ║                  Menu Rector                ║')
        cf.p('╚═══════════════════════════════════════════════ ╝ ╦═════════╗')
        cf.p('                                                  ║         ')
        cf.p('╔                                                           ╗')
        cf.p(' [1] Areas     | [5] Estudiantes')
        cf.p(' [2] Docentes  | [6] Contraseña')
        cf.p(' [3] Eventos   | [7] Acudientes ')
        cf.p(' [4] Directivos| [8] <<<< Salir')
        cf.p('╚                                                           ╝')
        cf.es()
    @staticmethod
    def menu_secretario_():
        cf.es()
        cf.p('║  ╔══════════════════════════════════════════╗')
        cf.p('  ║  Menu secretaria institucional             ║')
        cf.p('╚════════════════════════════════════════════════╝')
        cf.es()
        cf.p('╔                                                ╗')
        cf.p(' [1] Matricular estudiante   |  [3] Directivos')
        cf.p(' [2] Ver estudiante          |  [4] <<<< Salir')
        cf.p('╚                                                ╝')
        cf.es()
    @staticmethod
    def menu_principal_():
        cf.p('╔══════════════════════════════════════════╗')
        cf.p('  ║             SISTEMA ESCOLAR               ║')
        cf.p('  ╚════════════════════════════════════════════════╝ ')
        cf.p("    ║                 v1.6                    ║")
        cf.es()
        cf.p('╔ ◉ Coordinador | ◉ Estudiante    | ◉ secretaria ╗')
        cf.p('  ◉ Rector      | ◉ Acudiente     | ◉ info ')
        cf.p('╚ ◉ Docente     | ◉ herramientas                 ╝')
        cf.es()

class Submenus:
    @staticmethod
    def submenu_areas_():
        cf.linea_submenu()
        cf.p('                  Areas                ')
        cf.linea_submenu()
        cf.es()
        cf.p('□ temas de cada area □')
        cf.es()
        cf.p('(1) Naturales')
        cf.p('(2) Fisica')
        cf.p('(3) Sociales')
        cf.p('(4) Filosofia')
        cf.p('(5) Ingles')
        cf.p('(6) Edu Fisica')
        cf.p('(7) Religion')
        cf.p('(8) Etica')
        cf.p('(9) Castellano')
        cf.p('(10) Tecnologia')
        cf.p('(11) Economia y politica')
        cf.p('(12) Matematicas')
        cf.es()
        cf.p('(13) <<<< Volver')
        cf.es()
    @staticmethod
    def submenu_docentes_area_():
        cf.p('□ Docentes de area □')
        cf.es()
        cf.p('[1] Naturales')
        cf.p('[2] Fisica')
        cf.p('[3] Sociales')
        cf.p('[4] Filosofia')
        cf.p('[5] Ingles')
        cf.p('[6] Edu Fisica')
        cf.p('[7] Religion')
        cf.p('[8] Etica')
        cf.p('[9] Castellano')
        cf.p('[10] Tecnologia')
        cf.p('[11] Economia politica')
        cf.p('[12] Matematicas')
        cf.p('[13] <<<< Volver')
        cf.es()
    @staticmethod
    def submenu_eventos_():
        cf.linea_submenu()
        cf.p('           Eventos             ')
        cf.p('       Institucionales        ')
        cf.linea_submenu()
        cf.es()
        cf.p('[1] Dia cultura')
        cf.p('[2] Feria de la ciencia')
        cf.p('[3] Izada de bandera')
        cf.p('[4] Dia de la independencia')
        cf.p('[5] Reunion de padres de familia')
        cf.p('[6] << Volver')
        cf.es()
    @staticmethod
    def submenu_directivos_():
        cf.linea_submenu() 
        cf.p('         Directivos            ')
        cf.p('       institucionales         ')
        cf.linea_submenu()
        cf.es()
        cf.p('[1] Rector')
        cf.p('[2] Cordinador')
        cf.p('[3] Psicologa')
        cf.p('[4] Secretario academico')
        cf.p('[5] << Volver')
        cf.es()
    @staticmethod
    def submenu_eventos_1():
        cf.p('➤ Dia de la cultura')
        cf.es()
        cf.p('[1] Ver dia')
        cf.p('[2] Explicacion')
        cf.p('[3] << Volver')
        cf.es()
    @staticmethod
    def submenu_eventos_2():
        cf.p('➤ Feria de la ciencia')
        cf.es()
        cf.p('[1] Ver dia')
        cf.p('[2] Explicacion')
        cf.p('[3] << Volver')
        cf.es()
    @staticmethod
    def submenu_eventos_3():
        cf.p('➤ Izada de bandera')
        cf.es()
        cf.p('[1] Ver dias')
        cf.p('[2] Explicacion')
        cf.p('[3] << Volver')
        cf.es()
    @staticmethod
    def submenu_eventos_4():
        cf.p('➤ Dia de la independencia')
        cf.es()
        cf.p('[1] Ver dias')
        cf.p('[2] Explicacion')
        cf.p('[3] << Volver')
        cf.es()
    @staticmethod
    def submenu_eventos_5():
        cf.p('➤ Reunion de acudientes')
        cf.es()
        cf.p('[1] Ver dias')
        cf.p('[2] Explicacion')
        cf.p('[3] << Volver')
        cf.es()
    @staticmethod
    def submenu_directivos_1():
        cf.p('➤ RECTOR ')
        cf.es()
        cf.p('[1] Persona acargo')
        cf.p('[2] Funcion')
        cf.p('[3] << Volver')
        cf.es()
    @staticmethod
    def submenu_directivos_2():
        cf.p('➤ CORDINADOR')
        cf.es()
        cf.p('[1] Persona acargo')
        cf.p('[2] Funcion')
        cf.p('[3] <<<< Volver')
        cf.es()
    @staticmethod
    def submenu_directivos_3():
        cf.p('➤ PSICOLOGA')
        cf.es()
        cf.p('[1] Persona acargo')
        cf.p('[2] Funcion')
        cf.p('[3] <<<< Volver')
        cf.es()
    @staticmethod
    def submenu_directivos_4():
        cf.p('➤ SECRETARIO ACADEMICO')
        cf.es()
        cf.p('[1] Persona acargo')
        cf.p('[2] Funcion')
        cf.p('[3] <<<< Volver')
        cf.es()
    @staticmethod
    def cultura_1():
        while True:
            cf.p('► Dia a desarrollar')
            cf.es()
            cf.p('El dia a desarrollar este evento es el 1 de abril')
            cf.es()
            odecs1 = cf.salir_s()
            while odecs1 != 's':
                odecs1 = cf.salir_s()
            break
    @staticmethod
    def cultura_2():
        while True:
            cf.p('Evento donde los estudiantes presentan bailes, obras de teatro')
            cf.p('musica y expociciones. objetivgo mostrar los talentos')
            cf.p('artisticos')
            cf.es()
            cf.odecs2 = cf.salir_s()
            while odecs2 != 's':
                odecs2 = cf.salir_s()
            break
    @staticmethod
    def feria_1():
        while True:
            cf.p('► Dia a desarrollar')
            cf.p('El dia a desarrollar este evento es el 20 de agosto')
            cf.es()
            odefs1 = cf.salir_s()
            while odefs1 != 's':
                odefs1 = cf.salir_s()                
            break
    @staticmethod
    def feria_2():
        while True:
            cf.p('Actividad academica donde los estudiantes presentan')
            cf.p('experimentos cientificos, sirve para desarrollar la curiosidad,')
            cf.p('la ivestigacion y el pensamiento critico')
            cf.es()
            odefs2 = cf.salir_s()
            while odefs2 != 's':
                odefs2 = cf.salir_s()
            break  
    @staticmethod
    def izada_1():
        while True:
            cf.p('► Dia a desarrollar')
            cf.p('Esta actividad se desarrolla cada final de periodo,')
            cf.p('es decir. abril 15, agosto 21, noviembre 21')
            cf.es()
            cf.odeis1 = cf.salir_s()
            while odeis1 != 's':
                odeis1 = cf.salir_s()
            break
    @staticmethod
    def izada_2():
        while True:
            cf.p('Acto civico donde donde se rinden honores ala bandera,')
            cf.p('y se reconocen estudiantes destacados')
            cf.es()
            odeis2 = cf.salir_s()
            while odeis2 != 's':
                odeis2 = cf.salir_s()
            break  
    @staticmethod
    def independencia_1():
        while True:
            cf.p('► Dia a desarrollar')
            cf.p('El dia de el desarrollo de el evento es')
            cf.p('20 de agosto')
            cf.es()
            odeins1 = cf.salir_s()
            while odeins1 != 's':
                odeins1 = cf.salir_s()
            break
    @staticmethod
    def independencia_2():
        while True:
            cf.p('Es una actividad donde el colegio conmemora')
            cf.p('la historia de el pais, con actos civicos')
            cf.p('memorias culturales')
            cf.es()
            odeins2 = cf.salir_s()
            while odeins2 != 's':
                odeins2 = cf.salir_s()
            break
    @staticmethod
    def reunion_1():
        while True:
            cf.p('► Dia a desarrollar')
            cf.p('El dia de el desarrollo es dos dias despues')
            cf.p('de el final de periodo')
            cf.p('es decir. abril 15, agosto 21, noviembre 21')
            cf.es()
            oders1 = cf.salir_s()
            while oders1 != 's':
                oders1 = cf.salir_s()
            break
    @staticmethod
    def reunion_2():
        while True:
            cf.p('Reuniones organizadas por el colegio')
            cf.p('para orientar a los acudientes sobre la educacion,')
            cf.p('convivencia y desarrollo de los estudiantes')
            cf.es()
            oders2 = cf.salir_s()
            while oders2 != 's':
                oders2 = cf.salir_s()
            break    
    @staticmethod
    def submenu_compromisos_():
        cf.linea_submenu()
        cf.p('        Compromisos           ')
        cf.linea_submenu()
        cf.p('[1] Velar por la disciplina')
        cf.p('[2] Apoyar a los docentes')
        cf.p('[3] Supervisar procesos')
        cf.p('[4] Atender a estudiantes y padres')
        cf.p('[5] Cordinar actividades institucionales')
        cf.p('[6] <<<< Volver')
        cf.p('=*=*^=*=*=^=*=*=^')
    @staticmethod
    def submenu_reuniones():
        cf.linea_submenu()
        cf.p('          Reuniones           ')
        cf.linea_submenu()
        cf.es()
        cf.p('[1] Reuniones con docentes')
        cf.p('[2] Reunion con padres de familia')
        cf.p('[3] Reunion de convivencia escolar')
        cf.p('[4] Reunion de seguimiento academico')
        cf.p('[5] Reunion con directivos')
        cf.p('[6] <<<< Volver')
        cf.p('=*=*^=*=*=^=*=*=^')
        cf.es()
    @staticmethod
    def submenu_notas():
        cf.linea_menu2()
        cf.p('Notas estudiante')
        cf.linea_menu2()
        cf.es()
        cf.p('[1] Añadir nota estudiante')
        cf.p('[2] Ver nota estudiante')
        cf.p('[3] <<<< Volver')
    @staticmethod
    def submenu_añadir_es():
        cf.linea_submenu()
        cf.p('Sub menu añadir estudiante')
        cf.linea_submenu()
        cf.es()
        cf.p('[1] Añadir estudiante')
        cf.p('[3] <<<< volver')
        cf.es()
    @staticmethod
    def submenu_calculadora_():
        cf.linea_submenu()
        cf.p('        Calculadora')
        cf.linea_submenu()
        cf.es()
        cf.p('[1] iniciar calculadora')
        cf.p('[2] <<<< Volver')
        cf.es()
    @staticmethod
    def submenu_generador():
        cf.linea_submenu()
        cf.p('         Generador de contraseñas segurastas                ')
        cf.linea_submenu()
        cf.es()
        cf.p('[1] Empezar')
        cf.p('[2] <<<< Volver')
        cf.es()
    @staticmethod
    def submenu_juegos_():
        cf.linea_submenu()
        cf.p('             Juegos           ')
        cf.linea_submenu()
        cf.es()
        cf.p('[1] Number Hunter')
        cf.p('[2] Piedra papel o tijera')
        cf.p('[3] <<<< Volver')
        cf.es()
    @staticmethod
    def submenu_juegos_1():
        cf.p('➤ Number hunter')
        cf.es()
        cf.p('[1] Iniciar juego')
        cf.p('[2] <<<< Volver')
        cf.es()
    @staticmethod
    def submenu_juegos_2():
        cf.p('➤ Piedra papel o tijera')
        cf.es()
        cf.p('[1] Iniciar juego')
        cf.p('[2] <<<< Volver')
        cf.es()
    @staticmethod
    def submenu_invertir():
        cf.es()
        cf.p('[1] invertir contraseña')
        cf.p('[2] Guardar contraseña')
        cf.p('[3] <<<< Volver')
        cf.es()
    @staticmethod
    def submenu_contraseña_6():
        cf.p('================================================')
        cf.p('            Contraseña 6 dijitos              ')
        cf.p('================================================')
        cf.es()
        cf.p('[1] Contraseña de 6 dijitos numeros')
        cf.p('[2] Contraseña mixta')
        cf.p('[3] <<<< Volver')
        cf.es()
    @staticmethod
    def submenu_contraseña_8():
        cf.p('================================================')
        cf.p('              Contraseña 8 dijitos                ')
        cf.p('================================================')
        cf.es()
        cf.p('[1] Contraseña 8 dijitos numeros')
        cf.p('[2] Mixta')
        cf.p('[3] <<<< Volver')
        cf.es()
    @staticmethod
    def opcion_grado():
        cf.p('[1] Ver estudiantes')
        cf.p('[2] <<<< Volver')
        cf.es()
    @staticmethod
    def rector_1():
        while True:
            cf.p('► Rector institucional ')
            cf.p('jhon jairo vernal')
            cf.es()
            oddrs1 = cf.salir_s()
            while oddrs1 != 's':
                oddrs1 = cf.salir_s()
            break
    @staticmethod
    def rector_2():
        while True:
            cf.p('► Funcion rector')
            cf.p('Es la maxima autoridad de el colegio se encarga')
            cf.p('de dirigir la institucion, tomar deciciones y supervisar')
            cf.p('el funcionamiento de el colegio')
            cf.es()
            oddrs2 = cf.salir_s()
            while oddrs2 != 's':
                oddrs2 = cf.salir_s()
            break
    @staticmethod
    def coordinador_1():
        while True:
            cf.p('► Cordinador')
            cf.p('elder sanchez')
            cf.es()
            oddcs1 = cf.salir_s()
            while oddcs1 != 's':
                oddcs1 = cf.salir_s()
            break
    @staticmethod
    def coordinador_2():
        while True: 
            cf.p('► Funciones rector')
            cf.p('se encarga de organizar las clases, horarios')
            cf.p('materias, y actividades academicas')
            cf.p('tambien supervisa el trabajo de docente')
            cf.es()
            coddcs2 = cf.salir_s()
            while coddcs2 != 's':
                coddcs2 = cf.salir_s()
            break
    @staticmethod
    def psicologa_1():
        while True:
            cf.p('► Psicologa')
            cf.p('tatiana mendes')
            cf.es()
            oddps1 = cf.salir_s()
            while oddps1 != 's':
                oddps1 = cf.salir_s()
            break
    @staticmethod
    def psicologa_2():
        while True:
            cf.p('► funciones psicologa')
            cf.p('Se encarga principalmente de ayudar al bienestar emocional,')
            cf.p('social y academico de los estudiantes')
            cf.es()
            oddps2 = cf.salir_s()
            while oddps2 != 's':
                oddps2 = cf.salir_s()
            break   
    @staticmethod
    def secretario_1():
        while True:
            cf.p('► Secretario academico')
            cf.p('carlos ruben espitia')
            cf.es()
            oddss1 = cf.salir_s()
            while oddss1 != 's':
                oddss1 = cf.salir_s()
            break
    @staticmethod
    def secretario_2():
        while True:
            cf.p('► funciones secretario academico') 
            cf.p('Se encarga de las bases de datos,l registrar nuevos estudiantes')
            cf.es()
            oddss2 = cf.salir_s()
            while oddss2 != 's':
                oddss2 = cf.salir_s()
            break
    @staticmethod
    def submenu_anotacion():
        cf.p('➤ Anotaciones ')
        cf.es()
        cf.p('[1] Añadir anotacion')
        cf.p('[2] Ver anotacion')
        cf.p('[3] <<<< Volver')
        cf.es()
    @staticmethod
    def submenu_anotacion_2():
        cf.p('➤ Anotaciones ')
        cf.es()
        cf.p('[1] Ver anotacion')
        cf.p('[2] <<<< Volver')
        cf.es()
    @staticmethod
    def submenu_quitar_estudiante():
        cf.p('➤ Eliminar estudiante')
        cf.es()
        cf.p('[1] Quitar estudiante')
        cf.p('[2] <<<< Volver')
        cf.es()
    @staticmethod
    def submenu_cambiar_contraseña():
        cf.p('➤ Contraseña')
        cf.es()
        cf.p('[1] Cambiar contraseña')
        cf.p('[2] <<<< Volver')
        cf.es()
    @staticmethod
    def submenu_añadir_acudiente():
        cf.p('➤ Acudiente')
        cf.es()
        cf.p('[1] Añadir acudiente')
        cf.p('[2] Ver acudientes')
        cf.p('[3] <<<< Volver')
        cf.es()
    @staticmethod
    def submenu_añadir_boletin():
        cf.p('➤ Boletin')
        cf.es()
        cf.p('[1] Añadir boletin')
        cf.p('[2] Ver boletin')
        cf.p('[3] Exportar boletin a archivo txt')
        cf.p('[4] <<<< Volver')
        cf.es()
    @staticmethod
    def estudiantes_sistema_menu():
        cf.p('➤ Estudiantes')
        cf.es()
        cf.p('[1] Estudiantes')
        cf.p('[2] Añadir estudiante')
        cf.p('[3] Notas')
        cf.p('[4] Anotaciones')
        cf.p('[5] Boletines')
        cf.p('[6] <<<< Volver')
        cf.es()