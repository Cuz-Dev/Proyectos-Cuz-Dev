#menu Acudiente

while True:
    try:
        from configuracion import Configuracion as cf
        from UI import Menus as itz
        from Submenus.Submenu_docentes_area import Docente_por_area
        from Submenus.Submenu_directivos import SubmenuDirectivos
        from Submenus.Submenu_eventos import SubmenuEventos
        from estudiantes import mostrar_estudiantes,submenu_anotaciones_2
        break

    except ModuleNotFoundError:
        print("No se encontro un archivo::")


class Acudiente:
    def __init__(self):
        self.docentes = Docente_por_area()
        self.directivos = SubmenuDirectivos()
        self.eventos = SubmenuEventos()
        self.estudiantes_grado = mostrar_estudiantes()
        self.ver = mostrar_estudiantes()
        self.mostrar = submenu_anotaciones_2()

    def menu_acudiente(self):
        cf.limpiar_pantalla()        
        while True:
            itz.menu_acudiente_()
            opcion_acudiente = cf.entrada()
            opciones_acudiente = {
                1: self.ver.ver_estudiante_2,
                2: self.docentes.submenu_docentes_area,
                3: self.directivos.submenu_directivos,
                4: self.eventos.submenu_eventos,
                5: self.mostrar.Sub_Menu_Anotacion_2
            }

            if opcion_acudiente in opciones_acudiente:
                opciones_acudiente[opcion_acudiente]()

            elif opcion_acudiente == 6:
                cf.salir()
                cf.limpiar_pantalla()
                break