#Mneu info

while True:
    try:
        from configuracion import Configuracion as cf
        break

    except ModuleNotFoundError:
        print("No se eneontro un archivo")

class MenuInfo:   
    def menu_info(self):
        cf.limpiar_pantalla()
        cf.mostrar_info()
        cf.salir_menu_info()