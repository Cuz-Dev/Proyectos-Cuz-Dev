#Menu coordiandor

while True:
    try:
        from configuracion import Configuracion as cf
        from UI import Menus as itz
        from Submenus.Submenu_docentes_area import Docente_por_area
        from  Submenus.Submenu_compromisos import compromisos_
        from Submenus.Submenu_reuniones import reuniones_
        from auth.Auth import sub_menu_cambiar_contraseña
        from estudiantes import SubMenu_estudiantes_directivos
        from estudiantes import Sub_menu_añadir_acudiente
        from logins import login_coordinador
        break

    except ModuleNotFoundError:
        print("No se encuentra un archivo")

class MenuCoordinador:
    def __init__(self):
        self.docentes_disponibles = Docente_por_area()
        self.Sub_menu_compromisos = compromisos_()
        self.Sub_menu_reuniones = reuniones_()
        self.cambio = sub_menu_cambiar_contraseña()
        self.estudiantes = SubMenu_estudiantes_directivos()
        self.acudiente = Sub_menu_añadir_acudiente()

    def menu_coordinador(self):
        cf.limpiar_pantalla()
        login_coordinador()
        while True:
            cf.limpiar_pantalla()
            itz.menu_coordinador_()
            opcion_coordinador = cf.entrada()
            opciones_coordinador = {
                1: self.Sub_menu_compromisos.compromisos,
                2: self.Sub_menu_reuniones.reuniones,
                3: self.docentes_disponibles.submenu_docentes_area,
                4: self.estudiantes.Submenu_estudiantes,
                5:self.cambio.Sub_Menu_cambio,
                6:self.acudiente.SubMenu_añadir_acudiente
            }

            if opcion_coordinador in opciones_coordinador:
                cf.limpiar_pantalla()
                opciones_coordinador[opcion_coordinador]()

            else:
                cf.salir()
                cf.limpiar_pantalla()
                break