#Mnue rector

while True:
    try:
        from configuracion import Configuracion as cf
        from UI import Menus as itz
        from Submenus.Submenu_areas import SubmenuAreas
        from Submenus.Submenu_docentes_area import Docente_por_area
        from Submenus.Submenu_eventos import SubmenuEventos
        from Submenus.Submenu_directivos import SubmenuDirectivos
        from estudiantes import estudiantes_sistema, mostrar_estudiantes, notas_estudiante, submenu_anotaciones
        from estudiantes import SubMenu_estudiantes_directivos, Sub_menu_añadir_acudiente
        from auth.Auth import sub_menu_cambiar_contraseña
        from logins import login_rector
        break

    except ModuleNotFoundError:
        print("No se encontro un archivo")
class MenuRector:
    def __init__(self):
        self.areas_Temas = SubmenuAreas()
        self.docentes_Area = Docente_por_area()
        self.eventos_I = SubmenuEventos()
        self.directivos_I = SubmenuDirectivos()
        self.guardar = estudiantes_sistema()
        self.ver = mostrar_estudiantes()
        self.notas_estudiante = notas_estudiante()
        self.mostrar = submenu_anotaciones()
        self.cambio = sub_menu_cambiar_contraseña()
        self.estudiantes = SubMenu_estudiantes_directivos()
        self.acudiente = Sub_menu_añadir_acudiente()

    def Menu_rector(self):
        cf.limpiar_pantalla()
        login_rector()
        while True:
            cf.limpiar_pantalla()
            itz.menu_rector_()
            opcion_rector = cf.entrada()
            rector = {
                1: self.areas_Temas.submenu_areas,
                2: self.docentes_Area.submenu_docentes_area,
                3: self.eventos_I.submenu_eventos,
                4: self.directivos_I.submenu_directivos,
                5: self.estudiantes.Submenu_estudiantes,
                6: self.cambio.Sub_Menu_cambio,
                7:self.acudiente.SubMenu_añadir_acudiente
            }

            if opcion_rector in rector:
                cf.limpiar_pantalla()
                rector[opcion_rector]()
                
            else:
                cf.salir()
                cf.limpiar_pantalla()
                break