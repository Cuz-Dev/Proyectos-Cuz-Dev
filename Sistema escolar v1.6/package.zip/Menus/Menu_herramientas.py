#Mneu herramientas

while True:
    try:
        from configuracion import Configuracion as cf
        from Calculadora.Calculadora_basica import calculadora
        from Piedra_papel_tijera.piedra_papel import piedra_papel_o_tijera
        from Number_Hunter.Number_hunter import Number_hunter
        from UI import Menus as itz
        from UI import Submenus as its
        from error import fallas
        break

    except ModuleNotFoundError:
        print("No se encontro un achivo")

class Menu_herramientas:
    def __init__(self):
        self.calculadora = calculadora()
        self.fallo_es = fallas()
        self.piedra = piedra_papel_o_tijera()
        self.number = Number_hunter()
    def menu_herramientas(self):
        cf.limpiar_pantalla()
        while True:
            itz.menu_herramientas_()
            opcion_herramientas = cf.entrada()
            if opcion_herramientas == 1:
                while True:
                    cf.limpiar_pantalla()
                    its.submenu_calculadora_()
                    opcion_calculadora = cf.entrada()
                    if opcion_calculadora == 1:
                        while True:
                            try:
                                self.calculadora.menu_principal()
                                break

                            except ModuleNotFoundError:
                                self.fallo_es.failed_file_es()

                    elif opcion_calculadora == 2:
                        cf.volver()
                        cf.limpiar_pantalla()
                        break
                
            elif opcion_herramientas == 2:
                while True:
                    cf.limpiar_pantalla()
                    its.submenu_juegos_()
                    opcion_juegos = cf.entrada()
                    if opcion_juegos == 1:
                        while True:
                            its.submenu_juegos_1()
                            while True:
                                try:
                                    opcion_number_hunter = cf.entrada_us()
                                    cf.es()
                                    break

                                except ValueError:
                                    cf.error()

                            if opcion_number_hunter == 1:
                                while True:
                                    try:
                                        self.number.Menu_principal()
                                        break

                                    except ModuleNotFoundError:
                                        self.fallo_es.failed_file_es()

                            elif opcion_number_hunter == 2:
                                cf.volver()
                                cf.limpiar_pantalla()
                                break    

                    elif opcion_juegos == 2:
                        while True:
                            its.submenu_juegos_2()
                            opcion_piedra_papel = cf.entrada()
                            if opcion_piedra_papel == 1:
                                while True:
                                    try:
                                        self.piedra.inicio()
                                        break

                                    except ModuleNotFoundError:
                                        self.fallo_es.failed_file_es()

                            elif opcion_piedra_papel == 2:
                                cf.volver()
                                cf.limpiar_pantalla()
                                break

                    elif opcion_juegos == 3:
                        cf.volver()
                        cf.limpiar_pantalla()
                        break

            elif opcion_herramientas == 3:
                cf.salir()
                cf.limpiar_pantalla()
                break
