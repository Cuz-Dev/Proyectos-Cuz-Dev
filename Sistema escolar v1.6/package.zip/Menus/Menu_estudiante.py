#Menu estudiante

while True:
    try:
        from configuracion import Configuracion as cf
        from Submenus.Submenu_areas import SubmenuAreas
        from Submenus.Submenu_directivos import SubmenuDirectivos
        from estudiantes import mostrar_estudiantes
        from estudiantes import submenu_anotaciones_2
        from UI import Menus as itz
        break

    except ModuleNotFoundError:
        print("No se encontro un achivo")


class Menu_Estudiante:
    def __init__(self):
        self.areas_temas = SubmenuAreas()
        self.directivos = SubmenuDirectivos()
        self.estudiantes_grado = mostrar_estudiantes()
        self.ver = mostrar_estudiantes()
        self.mostrar = submenu_anotaciones_2()

    def menu_estudiante(self):
        cf.limpiar_pantalla()
        while True:
            itz.menu_es()
            opcion_estudiante = cf.entrada()
            estudiante_opcion = {

                1: self.areas_temas.submenu_areas,
                2: self.directivos.submenu_directivos,
                3: self.ver.ver_estudiante_2,
                4: self.mostrar.Sub_Menu_Anotacion_2
            }

            if opcion_estudiante in estudiante_opcion:
                estudiante_opcion[opcion_estudiante]()
                
            elif opcion_estudiante == 5:
                cf.salir()
                cf.limpiar_pantalla()
                break