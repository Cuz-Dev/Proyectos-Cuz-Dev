#Menu Secretario virtual

while True:
    try:
        from configuracion import Configuracion as cf
        from UI import Menus as itz
        from Submenus.Submenu_directivos import SubmenuDirectivos
        from estudiantes import estudiantes_sistema, mostrar_estudiantes
        break

    except ModuleNotFoundError:
        print("No se encontro un archivo")

class secretario_virtual:
    def __init__(self):
        self.directivos = SubmenuDirectivos()
        self.guardar = estudiantes_sistema()
        self.visualizar = mostrar_estudiantes()

    def menu_secretario(self):
        while True:
            cf.limpiar_pantalla()
            itz.menu_secretario_()
            opcion_secretaria = cf.entrada()
            opciones_secretaria = {
                1: self.guardar.menu.menu_guardado,
                2: self.visualizar.ver_estudiante,
                3: self.directivos.submenu_directivos
            }

            if opcion_secretaria in opciones_secretaria:
                opciones_secretaria[opcion_secretaria]()

            elif opcion_secretaria == 4:
                cf.salir()
                cf.limpiar_pantalla()
                break