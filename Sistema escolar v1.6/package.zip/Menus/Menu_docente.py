#Menu docente

while True:
    try:
        from configuracion import Configuracion as cf
        from UI import Menus as itz
        from Submenus.Submenu_areas import SubmenuAreas
        from Submenus.Submenu_eventos import SubmenuEventos
        from Submenus.Submenu_directivos import SubmenuDirectivos
        from auth.Auth import sub_menu_cambiar_contraseña
        from logins import login_docente
        from estudiantes import SubMenu_estudiantes_directivos
        from estudiantes import Sub_menu_añadir_acudiente
        break

    except ModuleNotFoundError:
        print("No se encontro un archivo")

class MenuDocente:
    def __init__(self,):
        self.areas = SubmenuAreas()
        self.eventos = SubmenuEventos()
        self.directivos = SubmenuDirectivos()
        self.cambio = sub_menu_cambiar_contraseña()
        self.estudiantes = SubMenu_estudiantes_directivos()
        self.acudiente = Sub_menu_añadir_acudiente()

    def menu_docente(self):
        cf.limpiar_pantalla()
        login_docente()
        while True:
            cf.limpiar_pantalla()
            itz.menu_docente()
            opcion_docente = cf.entrada()
            opciones_docente = {

                1: self.areas.submenu_areas,
                2: self.eventos.submenu_eventos,
                3: self.directivos.submenu_directivos,
                4: self.estudiantes.Submenu_estudiantes,
                5: self.cambio.Sub_Menu_cambio,
                6:self.acudiente.SubMenu_añadir_acudiente,
                
            }

            if opcion_docente in opciones_docente:
                cf.limpiar_pantalla()
                opciones_docente[opcion_docente]()

            else:
                cf.salir()
                cf.limpiar_pantalla()
                break