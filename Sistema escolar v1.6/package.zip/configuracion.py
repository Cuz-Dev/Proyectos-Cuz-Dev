#funciones

import os
class Configuracion:
    @staticmethod
    def curso_ejemplo():
        cf.p('Ejemplo "1" ')
    @staticmethod
    def es():
        print('  ')
    @staticmethod
    def pause():
        Configuracion.es()
        input('Presiona enter para salir <')
        Configuracion.es()
    @staticmethod
    def limpiar_pantalla():
        if os.name == "nt":
            os.system("cls")

        else:
            os.system("clear")
    @staticmethod
    def p(mensaje):
        print(mensaje)
    @staticmethod
    def error():
        Configuracion.es()
        print('[ERROR 505] Debes escribir un numero no una letra')
        Configuracion.es()
    @staticmethod
    def volver():
        print('<<<<')
        Configuracion.es()
    @staticmethod
    def salir():
        print('Saliendo*.*')
        Configuracion.es()
    @staticmethod
    def entrada_us():
        while True:
            try:
                numero = int(input('Digite numero de opcion:'))
                break

            except ValueError:
                print("Debes escribir un numero no una letra: ")
        return numero
    @staticmethod
    def Eof():
        cf.p('[ERROR 404] Existe un error con tu compilador:') 
    @staticmethod
    def grado_ejemplo():
        cf.p('Ejemplo "10" ')
    @staticmethod
    def curso_es():
        return str(input('Digite el curso: ')).strip()
    @staticmethod
    def curso_inesistente():
        cf.p('[ERROR] Ese curso no existe: ')
    @staticmethod
    def grado_inesistente():
        cf.p('[ERROR] Ese grado no existe: ')
    @staticmethod
    def generando():
        cf.es()
        cf.p('Generando □ ■ ▫ ▪')
    @staticmethod
    def guardando():
        cf.es()
        cf.p('Guardando □ ■ ▫ ▪')
        cf.es()
    @staticmethod
    def guardado_exito():
        cf.es()
        cf.p('Guardado con exito ¡! En save password.txt')
        cf.es()
    @staticmethod
    def finalized():
        cf.p('Contraseña finalizada Con exito: ')
    @staticmethod
    def linea_menu():
        cf.p('────────────────────────────────────────────────')
    @staticmethod
    def linea_menu2():
        cf.p('------------------------------------------------')
    @staticmethod
    def linea_submenu():
        cf.p('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
    @staticmethod
    def error_es():
        cf.p('[ERROR 101] No se encuentra el archivo save password.txt')
        cf.p('!¡Sin ese archivo no se puede guardar las contraseñas que crees¡!')
    @staticmethod
    def salir_s():
        return str(input('Escribe s para salir:')).lower()
    @staticmethod
    def error_usuario():
        cf.es()
        cf.p('[ERROR] Nombre de usuario invalido: ')
        cf.es()
    @staticmethod
    def grado_es():
        return str(input('Digite el grado: '))
    staticmethod
    def curso_es():
        return str(input('Digite el curso: '))
    @staticmethod
    def entrada():
        while True:
            try:
                opcion = int(input('dijita numero de opcion:'))
                cf.es()
                break

            except ValueError:
                cf.limpiar_pantalla()
                cf.error()

        return opcion
    @staticmethod
    def salir_menu_info():
        while True:
            try:
                sa = int(input('Escribe 1* para salir:'))
                while sa != 1:
                    sa = int(input('!¡Escribe 1 para salir¡!:'))
                break

            except ValueError:
                cf.error()

    def mostrar_info():
        while True:
            try:
                cf.es()
                with open("info.txt", "r") as archivo:
                    for linea in archivo:
                        cf.p(linea.strip())
                break
            except ModuleNotFoundError:
                cf.p('NO se encuentra el archivo info.txt')
    @staticmethod
    def anotacion_():
        lineas = []

        cf.p('Escribe la anotacion')
        cf.p('Para finalizar anotacion escribe Fn')
        cf.es()
        cf.p('Anotacion: ')

        while True:
            texto = input()

            if texto == 'Fn':
                break

            lineas.append(texto)

            anotacion = "\n".join(lineas)
        return anotacion
    @staticmethod
    def s_n():
        opcion = str(input('seguro que quieres borrar este estudiante s|n :'))
        return opcion
    @staticmethod
    def borrado_exitoso():
        print('Se elimino al estudiante de la base de datos:')
    @staticmethod
    def entrada_usuario():
        return str(input('║ Usuario: ')).lower().strip()
    @staticmethod
    def contraseña_usuario():
        while True:
            try:
                contraseña = int(input('Contraseña: '))
                break

            except ValueError:
                cf.error()
        return contraseña
    @staticmethod
    def pedir_tipo_de_usuario():
        return str(input('Escribe el tipo de directivo: ')).lower().strip()
    @staticmethod
    def contraseña_incorrecta():
        cf.p('contraseña incorrecta')
    @staticmethod
    def contraseña_invalida():
        cf.p('Contraseña invalida:')
        cf.p('Tenga encuenta: ')
        cf.p('1. 6 valores')
        cf.p('2. valores numericos no letras ni simbolos')
    @staticmethod
    def pedir_nueva_contraseña():
        print('Maximo 6 numeros')
        print('no letras')
        while True:
            try:
                nueva = int(input('digite nueva contraseña: '))
                cf.es()
                break

            except ValueError:
                cf.contraseña_invalida()

        while True:
            if len(str(nueva)) == 6:
                break

            else:
                cf.contraseña_incorrecta()
        
        return nueva

    @staticmethod
    def error_clave():
        cf.p('[ERROR] NO se pudo completar accion')
        cf.es()
        cf.p('Posibles causas')
        cf.es()
        cf.p('[1] el curso esta vacio')
        cf.p('y escribiste un apellido,')
        cf.es()
        cf.p('[2] escribiste mal el apellido')
    @staticmethod
    def grado_invalido():
        cf.p('[ERROR] Grado ivalido')
        cf.es()
        cf.p('Grados permitidos')
        cf.es()
        cf.p('6')
        cf.p('7')
        cf.p('8')
        cf.p('9')
        cf.p('10')
        cf.p('11')
    @staticmethod
    def curso_invalido():
        cf.p('[ERROR] Curso ivalido')
        cf.es()
        cf.p('Cursos permitidos')
        cf.es()
        cf.p('1')
        cf.p('2')
        cf.p('3')
    @staticmethod
    def pedir_nombre_guardar():
        return str(input('Escribe el nombre de el estudiante: ')).capitalize().strip()
    @staticmethod
    def pedir_apellido_guardar():
        return str(input('Escribe el apellido: ')).capitalize().strip()
    @staticmethod
    def pedir_grado_guardar():
        return str(input('Dijita el grado: '))
    @staticmethod
    def pedir_curso_guardar():
        return str(input('Dijita el curso: '))
    @staticmethod
    def numero_invalido():
        print('[ERROR] Por favor escribe un numero: ')
    @staticmethod
    def grados_validos():
        grados = [
            '6',
            '7',
            '8',
            '9',
            '10',
            '11',
        ]
        return grados
    @staticmethod
    def cursos_validos():
        cursos = [
            '1',
            '2',
            '3',
        ]
        return cursos
    @staticmethod
    def error_nota_estudiante():
        cf.p('[ERROR] No se logro añadir nota')
        cf.es()
        cf.p('Debido a que el estudiante no existe')
        cf.es()
        cf.p(' y pusiste un apellido el cual no existe')
        cf.p('Añade el estudiante primero')
    @staticmethod
    def error_anotacion_estudiante():
        cf.p('[ERROR] No se logro añadir anotaciones')
        cf.es()
        cf.p('Debido a que el estudiante no existe')
        cf.es()
        cf.p(' y pusiste un apellido el cual no existe')
        cf.p('Añade el estudiante primero')
        cf.es()
        cf.p('O verifica si escribiste bien el apellido')
    @staticmethod
    def error_boletin_estudiante():
        cf.p('[ERROR] No se logro añadir boletin')
        cf.p('Debido a que el estudiante no existe')
        cf.es()
        cf.p(' o pusiste un apellido el cual no existe')
        cf.p('Añade el estudiante primero')
        cf.es()
        cf.p('O verifica si escribiste bien el apellido')
    @staticmethod
    def pedir_nombre_acudiente():
        return str(input('Escribe el nombre de el acudiente: ')).lower().strip()
    @staticmethod
    def pedir_periodo():
        while True:
            try:
                periodo = int(input("Digita periodo actual para boletin: "))
                break
            except ValueError:
                cf.error()
        return periodo
    @staticmethod
    def pedir_numero_boletin():
        while True:
            try:
                numero = int(input("Digita numero de boletin: "))
                break

            except ValueError:
                cf.error()
        return numero
    @staticmethod
    def pedir_apellido_boletin():
        return str(input("Escribe el apellido de el estudiante: ")).capitalize()
    @staticmethod
    def inicio_():
        persona = str(input('>> Escribe el nombre de el menu:')).lower().strip()
        return persona

cf = Configuracion()

