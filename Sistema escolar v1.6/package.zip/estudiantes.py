#Estudiantes de SISTEMA
import json
import os
def error_():
    print('[Errror critico] No se encuentran los demas archivos:')

while True:
    try:
        from configuracion import Configuracion as cf
        from UI import Submenus as itz
        from utilidades import pedir_apellido
        break

    except ModuleNotFoundError:
        error_()

class estudiantes_sistema:
    def __init__(self):
        self.guardar = guardar_estudiante()
        self.menu = MenuGuardado()
        
    
class SubMenu_estudiantes_directivos:
    def __init__(self):
        self.menu = MenuGuardado()
        self.ver = mostrar_estudiantes()
        self.guardado = estudiantes_sistema()
        self.añadir_notas = menu_añadir_nota()
        self.anotaciones = submenu_anotaciones()
        self.guardad = guardar_estudiante()
        self.boletin = sub_menu_añadir_boletin()

    def Submenu_estudiantes(self):
        while True:
            cf.limpiar_pantalla()
            itz.estudiantes_sistema_menu()
            opcion = cf.entrada_us()
            opciones = {
                1:self.ver.ver_estudiante,
                2:self.guardado.menu.menu_guardado,
                3:self.añadir_notas.Menu_añadir,
                4:self.anotaciones.Sub_Menu_Anotacion,
                5:self.boletin.SubMenu_añadir_boletin
            }
            if opcion in opciones:
                cf.limpiar_pantalla()
                opciones[opcion]()

            else:
                cf.limpiar_pantalla()
                break
        

class MenuGuardado:
    def __init__(self):
        self.guardad = guardar_estudiante()
    def menu_guardado(self):
        while True:
            cf.limpiar_pantalla()
            itz.submenu_añadir_es()
            while True:
                try:
                    guardado = cf.entrada_us()
                    break

                except ValueError:
                    cf.error()

            if guardado == 1:
                cf.limpiar_pantalla()
                self.guardad.datos_es()
                self.guardad.guardado()

            else:
                cf.limpiar_pantalla()
                break

class guardar_estudiante:
    def __init__(self):
        self.estudiante = {}
        self.mostrar = estudiante_ver()

    def datos_es(self):
        cf.limpiar_pantalla()
        self.nombre = cf.pedir_nombre_guardar()
        cf.es()
        self.apellido = cf.pedir_apellido_guardar()
        cf.es()
        cf.grado_ejemplo()
        cf.es()
        self.grado = cf.pedir_grado_guardar()
        cf.es()
        grados = cf.grados_validos()
        cursos = cf.cursos_validos()
        while True:
            if self.grado.isdigit():
                break
            else:
                cf.limpiar_pantalla()
                cf.numero_invalido()
                self.grado = cf.pedir_grado_guardar()
        while True:
            if self.grado in grados:
                break
            else:
                cf.limpiar_pantalla()
                cf.grado_invalido()
                self.grado = cf.pedir_grado_guardar()
        while True:
            cf.curso_ejemplo()
            cf.es()
            self.curso = cf.pedir_curso_guardar()
            cf.es()
            if self.curso.isdigit():
                break
            else:
                cf.limpiar_pantalla()
                cf.numero_invalido()
                self.curso = cf.pedir_curso_guardar()
        while True:
            if self.curso in cursos:
                break
            else:
                cf.limpiar_pantalla()
                cf.curso_invalido()
                self.curso = cf.pedir_curso_guardar()  

    def guardado(self):
        print(self.grado)
        print(self.curso)
        nuevo = {

            self.apellido: {
                'Nombre': self.nombre,
                'notas': {},
                'anotaciones': [],
                'acudiente': {},
                'boletines': []

            }

        }

        with open("estudiantes.json", "r") as f:
            self.estudiantes = json.load(f)

        self.estudiantes.setdefault(self.grado, {})
        self.estudiantes[self.grado].setdefault(self.curso, {})
        self.estudiantes[self.grado][self.curso].update(nuevo)

        with open("estudiantes.json", "w") as f:
            json.dump(self.estudiantes, f, indent=4)


    def notas_es(self):
        cf.es()
        materias = [

            "Matematicas",
            "Edu fisica",
            "Catellano",
            "Ingles",
            "Biologia",
            "Filosofia",
            "Tecnologia",
            "Fisica",
            "Sociales",
            "Quimica",
            "Artistica",
        ]

        for i, materia in enumerate(materias):
            print(f"{i + 1}. {materia}")

        while True:
            try:
                seleccion_usuario = cf.entrada_us()
                cf.es()
                break

            except ValueError:
                cf.error()
        cf.limpiar_pantalla()
        self.mostrar.opcion_usuario()
        seleccion_es = pedir_apellido()
        with open("estudiantes.json", "r") as archivo:
            datos = json.load(archivo)

        while True:        
            nota = float(input("Ingrese nota: "))
            cf.es()

            if nota > 0 and nota <= 5:
                materia = materias[seleccion_usuario - 1]
                while True:
                    try:
                        estudiante_nota = datos[self.mostrar.grado][self.mostrar.curso][seleccion_es]
                        break
                    except KeyError:
                        cf.error_clave()
                        break
                while True:
                    try:
                        if "notas" not in estudiante_nota:
                            estudiante_nota["notas"] = {}
                        if materia not in estudiante_nota["notas"]:
                            estudiante_nota["notas"][materia] = []
                        estudiante_nota["notas"][materia].append(nota)
                        break

                    except UnboundLocalError:
                        cf.error_nota_estudiante()
                        cf.pause()
                        break

                with open("estudiantes.json", "w") as archivo_json:
                    json.dump(datos, archivo_json, indent=4)
                break

            else:
                print('nota invalida')

class menu_añadir_nota:
    def __init__(self):
        self.añadir = guardar_estudiante()
        self.ver_notas = notas_estudiante()

    def Menu_añadir(self):
        while True:
            cf.limpiar_pantalla()
            itz.submenu_notas()
            while True:
                try:
                    opcion_submenu = cf.entrada_us()
                    cf.es()
                    break

                except ValueError:
                    cf.error()

            opciones = {

                1: self.añadir.notas_es,
                2: self.ver_notas.ver_notas
            }

            if opcion_submenu in opciones:
                cf.limpiar_pantalla()
                opciones[opcion_submenu]()

            elif opcion_submenu == 3:
                cf.volver()
                cf.limpiar_pantalla()
                break


class mostrar_estudiantes:
    def __init__(self):
        self.estudiante = estudiante_ver()
        self.quitar = quitar_estudiante()

    def ver_estudiante(self):
        while True:
            cf.limpiar_pantalla()
            cf.linea_menu2()
            cf.p('Estudiantes')
            cf.linea_menu2()
            cf.es()
            cf.p('[1] Ver estudiante')
            cf.p('[2] Borrar estudiante')
            cf.p('[3] <<<< Volver')
            cf.es()
            while True:
                try:
                    opcion_mostrar_estudiante = cf.entrada_us()
                    cf.es()
                    break

                except ValueError:
                    cf.error()

            opciones = {
                1: self.estudiante.opcion_usuario,
                2: self.quitar.Quitar_estudiante
            }

            if opcion_mostrar_estudiante in opciones:
                cf.limpiar_pantalla()
                opciones[opcion_mostrar_estudiante]()

            elif opcion_mostrar_estudiante == 3:
                cf.volver()
                cf.limpiar_pantalla()
                break

    def ver_estudiante_2(self):
        while True:
            cf.limpiar_pantalla()
            cf.linea_menu2()
            cf.p('Estudiantes')
            cf.linea_menu2()
            cf.es()
            cf.p('[1] Ver estudiante')
            cf.p('[2] <<<< Volver')
            cf.es()
            while True:
                try:
                    opcion_mostrar_2 = cf.entrada_us()
                    cf.es()
                    break

                except ValueError:
                    cf.error()
            opciones = {
                1: self.estudiante.opcion_usuario
            }
            if opcion_mostrar_2 in opciones:
                cf.limpiar_pantalla()
                opciones[opcion_mostrar_2]()

            else:
                cf.volver()
                cf.limpiar_pantalla()
                break

class estudiante_ver:
    def opcion_usuario(self):
        while True:
            grados = cf.grados_validos()
            cursos = cf.cursos_validos()
            while True:
                self.grado = cf.grado_es()
                if self.grado.isdigit():
                    break
                else:
                    cf.limpiar_pantalla()
                    cf.numero_invalido()
                    self.grado = cf.grado_es()
            while True:
                if self.grado in grados:
                    break
                else:
                    cf.limpiar_pantalla()
                    cf.grado_invalido()
                    self.grado = cf.grado_es()
            while True:
                self.curso = cf.curso_es()
                if self.curso.isdigit():
                    break
                else:
                    cf.limpiar_pantalla()
                    cf.numero_invalido()
                    self.curso = cf.curso_es()
            while True:
                if self.curso in cursos:
                    break
                else:
                    cf.limpiar_pantalla()
                    cf.curso_invalido()
                    self.curso = cf.curso_es()

            cf.limpiar_pantalla()
            with open("estudiantes.json", "r") as f:
                archivo = json.load(f)

            if self.grado in archivo:
                if self.curso in archivo[self.grado]:
                    lista = archivo[self.grado][self.curso]
                    print(f"Grado:{self.grado}")
                    print(f"    Curso: {self.curso}")
                    for i, (apellido, datos) in enumerate(lista.items(), start=1):
                        print(f"{i}: {datos['Nombre']} {apellido}")
                    cf.pause()
                    return lista
                else:
                    cf.limpiar_pantalla()
                    cf.curso_inesistente()
            else:
                cf.limpiar_pantalla()
                cf.grado_inesistente()
            break
        return self.grado
        return self.curso

class notas_estudiante:
    def ver_notas(self):
        grado = cf.grado_es()
        cf.es()
        curso = cf.curso_es()
        cf.es()
        with open("estudiantes.json", "r") as read:
            archivo = json.load(read)

        if grado in archivo:
            if curso in archivo[grado]:
                list = archivo[grado][curso]
                print(f"Grado: {grado}")
                print(f"Curso: {curso}")
                for i, (apellido, datos) in enumerate(list.items(), start=1):
                    print(f"{i}: {datos['Nombre']}{apellido}") 
                    print(f"{datos['notas']}")
                cf.pause()

            else:
                cf.curso_inesistente()

        else:
            cf.grado_inesistente()

class anotacion:
    def __init__(self):
        self.mostrar = estudiante_ver()
        self.g = guardar_estudiante()
        self.estudiante = {}

    def añadir_anotacion(self):
        with open('estudiantes.json', 'r') as d:
            archivo = json.load(d)

        self.mostrar.opcion_usuario()
        selecion_us = pedir_apellido()
        cf.limpiar_pantalla()
        an = cf.anotacion_()
        while True:
            try:
                anotaciones = archivo[self.mostrar.grado][self.mostrar.curso][selecion_us]
                break
            except KeyError:
                cf.limpiar_pantalla()
                cf.error_clave()
                break
        while True:
            try:
                if 'anotaciones' not in anotaciones:
                    anotaciones['anotaciones'] = []
                anotaciones['anotaciones'].append(an)
                break

            except UnboundLocalError:
                cf.limpiar_pantalla()
                cf.error_anotacion_estudiante()
                cf.pause()
                break

        with open('estudiantes.json', 'w') as j:
            json.dump(archivo, j, indent=4)

    def mostrar_anotacion(self):
        with open('estudiantes.json', 'r') as j:
            leer = json.load(j)
        self.mostrar.opcion_usuario()
        seleccion = cf.entrada_us()
        cf.limpiar_pantalla()
        lista_estudiantes = list(leer[self.mostrar.grado][self.mostrar.curso].keys())
        while True:
            try:
                apellido = lista_estudiantes[seleccion - 1]
                break

            except IndexError:
                break
        while True:
            try:
                anotaciones = leer[self.mostrar.grado][self.mostrar.curso][apellido]['anotaciones']
                for i, texto in enumerate(anotaciones, start=1):
                    print(f"{i}. {texto}")
                cf.pause()
                break

            except UnboundLocalError:
                break

class submenu_anotaciones:
    def __init__(self):
        self.guardar = anotacion()

    def Sub_Menu_Anotacion(self):
        while True:
            cf.limpiar_pantalla()
            itz.submenu_anotacion()
            opcion = cf.entrada()
            opciones_anotacion = {

                1:self.guardar.añadir_anotacion,
                2: self.guardar.mostrar_anotacion

            }

            if opcion in opciones_anotacion:
                cf.limpiar_pantalla()
                opciones_anotacion[opcion]()

            elif opcion == 3:
                cf.salir()
                cf.limpiar_pantalla()
                break        
        
class submenu_anotaciones_2:
    def __init__(self):
        self.mostrar = anotacion()

    def Sub_Menu_Anotacion_2(self):
        while True:
            cf.limpiar_pantalla()
            itz.submenu_anotacion_2()
            opcion = cf.entrada()

            opciones_anotacion_2 = {

                1:self.mostrar.mostrar_anotacion
            }

            if opcion in opciones_anotacion_2:
                cf.limpiar_pantalla()
                opciones_anotacion_2[opcion]()

            elif opcion == 2:
                cf.salir()
                cf.limpiar_pantalla()
                break

class quitar_estudiante:
    def __init__(self):
        self.mostrar = estudiante_ver()

    def Quitar_estudiante(self):
        with open('estudiantes.json', 'r') as f:
            archivo = json.load(f)
        self.mostrar.opcion_usuario()
        cf.es()
        selecion = pedir_apellido()
        opcion = cf.s_n()

        if opcion == 's':
            if self.mostrar.grado in archivo:
                if self.mostrar.curso in archivo[self.mostrar.grado]:
                    while True:
                        try:
                            del archivo[self.mostrar.grado][self.mostrar.curso][selecion]
                            break

                        except KeyError:
                            cf.limpiar_pantalla()
                            cf.error_clave()
                            cf.pause()
                            break

                    with open('estudiantes.json', 'w') as d:
                        json.dump(archivo, d, indent=4)
                    cf.borrado_exitoso()

            else:
                cf.grado_inesistente()

        elif opcion == 'n':
            cf.limpiar_pantalla()

class submenu_quitar:
    def __init__(self):
        self.quitar = quitar_estudiante()

    def Submenu_Quitar(self):
        while True:
            itz.submenu_quitar_estudiante()
            opcion = cf.entrada_us()
            opciones = {
                1: self.quitar.Quitar_estudiante
            }

            if opcion in opciones:
                opciones[opcion]()

            else:
                cf.volver()
                cf.limpiar_pantalla()
                break

class acudientes:
    def __init__(self):
        self.mostrar = estudiante_ver()

    def añadir_acudiente(self):
        with open("estudiantes.json", "r") as f:
            archivo = json.load(f)
        self.mostrar.opcion_usuario()
        selecion = pedir_apellido()
        cf.limpiar_pantalla()
        while True:
            try:
                acudientes = archivo[self.mostrar.grado][self.mostrar.curso][selecion]["acudiente"]
                nombre_acudiente = cf.pedir_nombre_acudiente()
                if "nombres" not in acudientes:
                    acudientes["nombres"] = []
                acudientes["nombres"].append(nombre_acudiente)
                with open("estudiantes.json", "w") as d:
                    json.dump(archivo, d, indent=4)
                break

            except:
                cf.limpiar_pantalla()
                cf.error_clave()
                cf.pause()
                break
        
    def ver_acudientes(self):
        with open("estudiantes.json", "r") as f:
            archivo = json.load(f)
        self.mostrar.opcion_usuario()
        selecion = pedir_apellido()
        cf.limpiar_pantalla()
        while True:
            try:
                acudientes = archivo[self.mostrar.grado][self.mostrar.curso][selecion]["acudiente"]
                nombre = archivo[self.mostrar.grado][self.mostrar.curso][selecion]
                if "nombres" in acudientes:
                    print(f"Acudiente de {nombre["Nombre"]} {selecion}")
                    for nombre in acudientes["nombres"]:
                        print(nombre)
                        cf.pause()
                else:
                    cf.p('no hay acudientes registrados')
                    cf.pause()
                break

            except:
                cf.limpiar_pantalla()
                cf.error_clave()
                cf.pause()
                break

class Sub_menu_añadir_acudiente:
    def __init__(self):
        self.añadir = acudientes()

    def SubMenu_añadir_acudiente(self):
        while True:
            cf.limpiar_pantalla()
            itz.submenu_añadir_acudiente()
            opcion = cf.entrada_us()
            opciones = {
                1:self.añadir.añadir_acudiente,
                2:self.añadir.ver_acudientes
            } 
            if opcion in opciones:
                cf.limpiar_pantalla()
                opciones[opcion]()

            else:
                cf.limpiar_pantalla()
                break
        
class boletines:
    def __init__(self):
        self.mostrar = estudiante_ver()

    def crear_boletin(self):
        with open("estudiantes.json", "r") as f:
            archivo = json.load(f)

        self.mostrar.opcion_usuario()
        self.seleccion = pedir_apellido()
        self.periodo = cf.pedir_periodo()
        cf.limpiar_pantalla()
        while True:
            try:
                self.nombre = archivo[self.mostrar.grado][self.mostrar.curso][self.seleccion]
                boletin = archivo[self.mostrar.grado][self.mostrar.curso][self.seleccion]["boletines"]
                boletin_ = self.escribir_boletin()
                boletin.append(boletin_)
                break

            except:
                cf.error_boletin_estudiante()
                cf.pause()
                break

        with open("estudiantes.json", "w") as d:
            json.dump(archivo, d, indent=4)

    def escribir_boletin(self):
        with open("estudiantes.json", "r") as g:
            notas = json.load(g)

        estudiante = notas[self.mostrar.grado][self.mostrar.curso][self.seleccion]
        boletin = f"""
        ===================================
        Boletin grado{self.mostrar.grado}
                curso{self.mostrar.curso}
        Periodo: {self.periodo}
        ===================================
        Estudiante: {self.seleccion} {self.nombre["Nombre"]}

        Notas:

        """
        for materia, notas in estudiante["notas"].items():
            boletin += f"{materia}: {notas} \n"
        return boletin
    

class SubMenu_mostrar_boletin:
    def __init__(self):
        self.mostrar = estudiante_ver()
    def mostrar_boletin(self):
        self.mostrar.opcion_usuario()
        self.apellido = pedir_apellido()
        cf.limpiar_pantalla()
        with open("estudiantes.json", "r") as b:
            archivo = json.load(b)
        while True:
            try:
                ver_boletin = archivo[self.mostrar.grado][self.mostrar.curso][self.apellido]["boletines"]
                for i, boletin in enumerate(ver_boletin, start=1):
                    print(f"Boletin #{i}")
                    print(boletin)
                cf.es()
                cf.pause()
                break
            except:
                cf.limpiar_pantalla()
                cf.error_boletin_estudiante()
                cf.pause()
                break

        return self.mostrar.grado
        return self.mostrar.curso

class exportar_boletin:
    def __init__(self):
        self.mostrar = estudiante_ver()
        self.ver_boletin = SubMenu_mostrar_boletin()

    def exportar_boletines(self):
        with open("estudiantes.json", "r")  as l:
            archivo = json.load(l)
        self.ver_boletin.mostrar_boletin()
        numero = cf.pedir_numero_boletin()
        while True:
            try:
                boletin = archivo[self.ver_boletin.mostrar.grado][self.ver_boletin.mostrar.curso][self.ver_boletin.apellido]["boletines"][numero-1]
                os.makedirs("Boletines", exist_ok=True)
                os.makedirs(f"Boletines/{self.ver_boletin.mostrar.grado}", exist_ok=True)
                os.makedirs(f"Boletines/{self.ver_boletin.mostrar.grado}/{self.ver_boletin.mostrar.curso}", exist_ok=True)
                ruta = f"Boletines/{self.ver_boletin.mostrar.grado}/{self.ver_boletin.mostrar.curso}/boletin{self.ver_boletin.apellido}.txt"
                with open(ruta, "w", encoding="utf-8") as f:
                    f.write(boletin)
                break

            except:
                cf.limpiar_pantalla()
                cf.error_boletin_estudiante()
                cf.pause()
                break

class sub_menu_añadir_boletin:
    def __init__(self):
        self.añadir = boletines()
        self.mostrar = SubMenu_mostrar_boletin()
        self.exportar = exportar_boletin()

    def SubMenu_añadir_boletin(self):
        while True:
            cf.limpiar_pantalla()
            itz.submenu_añadir_boletin()
            opcion = cf.entrada_us()
            opciones = {
                1:self.añadir.crear_boletin,
                2:self.mostrar.mostrar_boletin,
                3:self.exportar.exportar_boletines
            }
            if opcion in opciones:
                cf.limpiar_pantalla()
                opciones[opcion]()

            else:
                cf.limpiar_pantalla()
                break
