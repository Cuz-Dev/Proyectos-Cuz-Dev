def error_():
    print('[Errror critico] No se encuentran los demas archivos:')

while True:
    try:
        from configuracion import Configuracion as cf
        break

    except ModuleNotFoundError:
        error_()

def temas_1():
    cf.limpiar_pantalla()
    cf.p('➤ Temas ciencias naturales')
    cf.p('• Animales        | • Quimica')
    cf.p('• Celulas         | • Laboratorio')
    cf.p('• Medio ambiente')
    cf.pause()

def temas_2():
    cf.limpiar_pantalla()
    cf.p('➤ Temas fisica materia')
    cf.es()
    cf.p('• Mru        |• Unidades de medida')
    cf.p('• Factores de conversion')
    cf.pause()

def temas_3():
    cf.limpiar_pantalla()
    cf.p('➤ Temas sociales')
    cf.es()
    cf.p('• Imperialismo')
    cf.p('• Socialismo')
    cf.p('• Comunismo')
    cf.p('• Nacionalismos')
    cf.pause()

def temas_4():
    cf.limpiar_pantalla()
    cf.p('➤ Temas filosofia')
    cf.es()
    cf.p('• Inicios de la filosofia')
    cf.p('• Principales pensadores de la edad media')
    cf.pause()

def temas_5():
    cf.limpiar_pantalla()
    cf.p('➤ Temas ingles')
    cf.es()
    cf.p('• Verb to be')
    cf.p('• Lisenig')
    cf.p('• Read')
    cf.pause()

def temas_6():
    cf.limpiar_pantalla()
    cf.p('➤ Temas edu. fisica')
    cf.es()
    cf.p('• Juegos tradicionales')
    cf.p('• Historia de el basquetball')
    cf.p('• Historia de el fottball')
    cf.pause()

def temas_7():
    cf.limpiar_pantalla()
    cf.p('➤ Temas religion')
    cf.es()    
    cf.p('• Sin sentidos')
    cf.p('• Sentidos')
    cf.p('• Yo pertenezco a jesus')
    cf.pause()

def temas_8():
    cf.limpiar_pantalla()
    cf.p('➤ Temas etica')
    cf.es()
    cf.p('• Sentimientos')
    cf.p('• Perdon')
    cf.p('• Valores')
    cf.pause()

def temas_9():
    cf.limpiar_pantalla()
    cf.p('➤ Temas  castellano')
    cf.es()
    cf.p('• La vida feliz')
    cf.p('• La metarmofosis')
    cf.p('• Noches blancas')
    cf.pause()

def temas_10():
    cf.limpiar_pantalla()
    cf.p('➤ Temas tecnologia')
    cf.es()
    cf.p('• Diagrama de flujo')
    cf.p('• Makecode')
    cf.p('• Python')
    cf.pause()

def temas_11():
    cf.limpiar_pantalla()
    cf.p('➤ Temas ciencias economicas y politicas')
    cf.es()
    cf.p('• Pensadores')
    cf.p('• Origen')
    cf.p('• Importancia')
    cf.pause()

def temas_12():
    cf.limpiar_pantalla()
    cf.p('➤ Temas matematicas')
    cf.es()
    cf.p('• Seno')
    cf.p('• Coseno')
    cf.p('• Tangente')
    cf.pause()

temas_area_lista = [temas_1, temas_2, temas_3, temas_4, temas_5, temas_6, temas_7, temas_8, temas_9, temas_10, temas_11, temas_12]  


def cultura_1():
    while True:
        cf.limpiar_pantalla()
        cf.p('► Dia a desarrollar')
        cf.es()
        cf.p('El dia a desarrollar este evento es el 1 de abril')
        cf.es()
        odecs1 = cf.salir_s()
        while odecs1 != 's':
            odecs1 = cf.salir_s()
        break

def cultura_2():
    while True:
        cf.limpiar_pantalla()
        cf.p('Evento donde los estudiantes presentan bailes, obras de teatro')
        cf.p('musica y expociciones. objetivgo mostrar los talentos')
        cf.p('artisticos')
        cf.es()
        odecs2 = cf.salir_s()
        while odecs2 != 's':
            odecs2 = cf.salir_s()
        break

def feria_1():
    cf.limpiar_pantalla()
    while True:
        cf.p('► Dia a desarrollar')
        cf.p('El dia a desarrollar este evento es el 20 de agosto')
        cf.es()
        odefs1 = cf.salir_s()
        while odefs1 != 's':
            odefs1 = cf.salir_s()                
        break

def feria_2():
    while True:
        cf.p('Actividad academica donde los estudiantes presentan')
        cf.p('experimentos cientificos, sirve para desarrollar la curiosidad,')
        cf.p('la ivestigacion y el pensamiento critico')
        cf.es()
        odefs2 = cf.salir_s()
        while odefs2 != 's':
            odefs2 = cf.salir_s()
        break  

def izada_1():
    while True:
        cf.p('► Dia a desarrollar')
        cf.p('Esta actividad se desarrolla cada final de periodo,')
        cf.p('es decir. abril 15, agosto 21, noviembre 21')
        cf.es()
        odeis1 = cf.salir_s()
        while odeis1 != 's':
            odeis1 = cf.salir_s()
        break

def izada_2():
    while True:
        cf.p('Acto civico donde donde se rinden honores ala bandera,')
        cf.p('y se reconocen estudiantes destacados')
        cf.es()
        odeis2 = cf.salir_s()
        while odeis2 != 's':
            odeis2 = cf.salir_s()
        break  

def independencia_1():
    while True:
        cf.p('► Dia a desarrollar')
        cf.p('El dia de el desarrollo de el evento es')
        cf.p('20 de agosto')
        cf.es()
        odeins1 = cf.salir_s()
        while odeins1 != 's':
            odeins1 = cf.salir_s()
        break

def independencia_2():
    while True:
        cf.p('Es una actividad donde el colegio conmemora')
        cf.p('la historia de el pais, con actos civicos')
        cf.p('memorias culturales')
        cf.es()
        odeins2 = cf.salir_s()
        while odeins2 != 's':
            odeins2 = cf.salir_s()
        break

def reunion_1():
    while True:
        cf.p('► Dia a desarrollar')
        cf.p('El dia de el desarrollo es dos dias despues')
        cf.p('de el final de periodo')
        cf.p('es decir. abril 15, agosto 21, noviembre 21')
        cf.es()
        oders1 = cf.salir_s()
        while oders1 != 's':
            oders1 = cf.salir_s()
        break

def reunion_2():
    while True:
        cf.p('Reuniones organizadas por el colegio')
        cf.p('para orientar a los acudientes sobre la educacion,')
        cf.p('convivencia y desarrollo de los estudiantes')
        cf.es()
        oders2 = cf.salir_s()
        while oders2 != 's':
            oders2 = cf.salir_s()
        break    

eventos_lista = [cultura_1, cultura_2, feria_1, feria_2, izada_1, izada_2, independencia_1, independencia_2, reunion_1, reunion_2]

def rector_1():
    while True:
        cf.p('► Rector institucional ')
        cf.p('jhon jairo vernal')
        cf.es()
        oddrs1 = cf.salir_s()
        while oddrs1 != 's':
            oddrs1 = cf.salir_s()
        break

def rector_2():
    while True:
        cf.p('► Funcion rector')
        cf.p('Es la maxima autoridad de el colegio se encarga')
        cf.p('de dirigir la institucion, tomar deciciones y supervisar')
        cf.p('el funcionamiento de el colegio')
        cf.es()
        oddrs2 = cf.salir_s()
        while oddrs2 != 's':
            oddrs2 = cf.salir_s()
        break

def coordinador_1():
    while True:
        cf.p('► Cordinador')
        cf.p('elder sanchez')
        cf.es()
        oddcs1 = cf.salir_s()
        while oddcs1 != 's':
            oddcs1 = cf.salir_s()
        break

def coordinador_2():
    while True: 
        cf.p('► Funciones rector')
        cf.p('se encarga de organizar las clases, horarios')
        cf.p('materias, y actividades academicas')
        cf.p('tambien supervisa el trabajo de docente')
        cf.es()
        oddcs2 = cf.salir_s()
        while oddcs2 != 's':
            oddcs2 = cf.salir_s()
        break

def psicologa_1():
    while True:
        cf.p('► Psicologa')
        cf.p('tatiana mendes')
        cf.es()
        oddps1 = cf.salir_s()
        while oddps1 != 's':
            oddps1 = cf.salir_s()
        break

def psicologa_2():
    while True:
        cf.p('► funciones psicologa')
        cf.p('Se encarga principalmente de ayudar al bienestar emocional,')
        cf.p('social y academico de los estudiantes')
        cf.es()
        oddps2 = cf.salir_s()
        while oddps2 != 's':
            oddps2 = cf.salir_s()
        break   

def secretario_1():
    while True:
        cf.p('► Secretario academico')
        cf.p('carlos ruben espitia')
        cf.es()
        oddss1 = cf.salir_s()
        while oddss1 != 's':
            oddss1 = cf.salir_s()
        break

def secretario_2():
    while True:
        cf.p('► funciones secretario academico') 
        cf.p('Se encarga de las bases de datos,l registrar nuevos estudiantes')
        cf.es()
        oddss2 = cf.salir_s()
        while oddss2 != 's':
            oddss2 = cf.salir_s()
        break

directivos_lista = [rector_1, rector_2, coordinador_1, coordinador_2, psicologa_1, psicologa_2, secretario_1, secretario_2]    

def docente_area_1():
    cf.p('➤ Ciencias naturales ')
    cf.es()
    cf.p('• dora')
    cf.p('• jhon')
    cf.p('• angelica')
    cf.pause()

def docente_area_2():
    cf.p('➤ Fisica')
    cf.es()
    cf.p('• angela')
    cf.p('• alex')    
    cf.p('• angel')
    cf.pause()

def docente_area_3():
    cf.p('➤ Sociales')
    cf.es()
    cf.p('• magdalena')
    cf.p('• mario')
    cf.p('• capera')
    cf.pause()

def docente_area_4():
    cf.p('➤ Filosofia')
    cf.es()
    cf.p('• capera')
    cf.p('• elsa')
    cf.pause()

def docente_area_5():
    cf.p('➤ Ingles')
    cf.es()
    cf.p('• carlos')
    cf.p('• sara')
    cf.pause()

def docente_area_6():
    cf.p('➤ Edu fisica')
    cf.es()
    cf.p('• sebastian')
    cf.pause()

def docente_area_7():
    cf.p('➤ Religion')
    cf.es()
    cf.p('• luz')
    cf.pause()

def docente_area_8():
    cf.p('➤ Etica')
    cf.es()
    cf.p('• luz')
    cf.pause()

def docente_area_9():
    cf.p('➤ Castellano')
    cf.es()
    cf.p('• magdalena')
    cf.p('• sofia')
    cf.pause()

def docente_area_10():
    cf.p('➤ Tecnologia')
    cf.es()
    cf.p('• geovanny')
    cf.pause()

def docente_area_11():
    cf.p('➤ Economia y Politica')
    cf.es()
    cf.p('• capera')
    cf.pause()

def docente_area_12():
    cf.p('➤ Matematica')
    cf.es()  
    cf.p('• ruben')
    cf.p('• angela')
    cf.pause()

docentes_area = [docente_area_1, docente_area_2, docente_area_3, docente_area_4, docente_area_5, docente_area_6, docente_area_7, docente_area_8, docente_area_9, docente_area_10, docente_area_11, docente_area_12]   

def compromisos_1():
    cf.limpiar_pantalla()
    cf.p('➤ Velar por la disciplina')
    cf.p('Garantizar que los estudiantes cumplan con las normas')
    cf.p('manual de convivencia de la institucion.')
    cf.pause()

def compromisos_2():
    cf.limpiar_pantalla()
    cf.p('➤ Apoyar a los docentes')
    cf.p('Ayudar a los profesores en la organizacion de actividades academicas,')
    cf.p('y resolver situaciones dentro del aula.')
    cf.pause()

def compromisos_3():
    cf.limpiar_pantalla()
    cf.p('➤ Supervisar procesos academicos')
    cf.p('Revisar que las clases, evaluaciones y actividades educativas')
    cf.p('se desarrollen correctamente.')
    cf.pause()

def compromisos_4():
    cf.limpiar_pantalla()
    cf.p('➤ Atender a estudiantes y padres de familia')
    cf.p('Escuchar problemas, inquietudes o conflictos de estudiantes ')
    cf.p('y acudientes para buscar soluciones')
    cf.pause()

def compromisos_5():
    cf.p('➤ Coordinar actividades isntitucionales')
    cf.p('Organizar eventos academicos, reuniones, proyectos educativos')
    cf.p('y actividades escolares')
    cf.pause()

def reuniones_1():
    cf.p('➤ Reunion con docentes')
    cf.p('• Rendimientos academico de los estudiantes')
    cf.p('• Planificar clases')
    cf.p('• Actividades escolares')
    cf.pause()

def reuniones_2():
    cf.p('➤ Reunion con padres de familia')
    cf.p('• Imformar sobre el comportamiento de los estudiantes')
    cf.p('• Explicar el progreso academico')
    cf.p('• Resolver inquietudes de los acudientes')
    cf.pause()

def reuniones_3():
    cf.p('➤ Reunion de convivencia escolar')
    cf.p('• Tratar conflictos entre estudiantes')
    cf.p('• Normas del colegio')
    cf.p('• Mejora deel ambiente escolar')
    cf.pause()

def reuniones_4():
    cf.p('➤ Reunion de seguimiento academico')
    cf.p('• Rendimiento de los estudiantes')
    cf.p('• Dificultades en ciertas materias')
    cf.p('• Estrategias para mejorar el aprendisaje')
    cf.pause()

def reuniones_5():
    cf.p('➤ Reunion con directivos')
    cf.p('• El cordinador se reune con el rector y otros responsables')
    cf.p('• para planificar actividades y desiciones de el')
    cf.p('• colegio')
    cf.pause()

def pedir_apellido():
    cf.p('Escribe el apellido de el estudiante: ')
    while True:
        try:
            apellido = str(input()).capitalize()
            cf.es()
            break

        except ValueError:
            cf.p('Debes escribir el apellido: ')
    return apellido
