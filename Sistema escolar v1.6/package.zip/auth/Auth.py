def error_():
    print('No es encuentra el archivo')

while True:
    try:
        from configuracion import Configuracion as cf
        from UI import Submenus as itz
        break

    except ModuleNotFoundError:
        error_()

import json
class cambiar_contraseña:
    def Cambiar_contraseña(self):
        with open('auth/logins.json', 'r') as t:
            archivo = json.load(t)
        Usuario = cf.pedir_tipo_de_usuario()
        cf.es()
        contraseña_us = cf.contraseña_usuario()
        cf.es()
        while True:
            try:
                contraseña = archivo['contraseñas'][Usuario]
                break

            except KeyError:
                break
        while True:
            try:
                if contraseña_us == contraseña:
                    cf.limpiar_pantalla()
                    nueva = cf.pedir_nueva_contraseña()
                    archivo['contraseñas'][Usuario] = nueva
                else:
                    cf.limpiar_pantalla()
                    cf.contraseña_incorrecta()
                    cf.pause()
                break


            except UnboundLocalError:
                break

        with open('auth/logins.json', 'w') as r:
            json.dump(archivo, r, indent=4)

        

class sub_menu_cambiar_contraseña:
    def __init__(self):
        self.cambiar = cambiar_contraseña()
    def Sub_Menu_cambio(self):
        while True:
            cf.limpiar_pantalla()
            itz.submenu_cambiar_contraseña()
            opcion = cf.entrada_us()
            cf.es()
            opciones = {
                1: self.cambiar.Cambiar_contraseña
            }
            if opcion in opciones:
                cf.limpiar_pantalla()
                opciones[opcion]()

            else:
                cf.volver()
                cf.limpiar_pantalla()
                break

        
